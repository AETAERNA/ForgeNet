#!/data/data/com.termux/files/usr/bin/python
import os, re, json, datetime, itertools, random
from collections import Counter, defaultdict

base = os.path.expanduser("~/forge")
paths = {
    "mce": os.path.join(base, "forgenet_meaning_convergence.json"),
    "srl": os.path.join(base, "forgenet_semantic_resonance.json"),
    "cae": os.path.join(base, "forgenet_cognitive_alignment.json")
}
out_json = os.path.join(base, "forgenet_linguistic_genesis.json")
out_txt  = os.path.join(base, "forgenet_linguistic_genesis.txt")

# === Ensure all layers exist ===
for key, path in paths.items():
    if not os.path.exists(path):
        print(f"⚠️ Missing dependency: {key.upper()} layer not found.")
        exit()

mce = json.load(open(paths["mce"]))
srl = json.load(open(paths["srl"]))
cae = json.load(open(paths["cae"]))

clusters = srl.get("clusters", [])
transitions = cae.get("transitions", {})

# === Step 1: Integrate semantic + alignment data ===
role_to_words = defaultdict(list)
for c in clusters:
    role = c.get("dominant_role","unknown")
    for w in c.get("members",[])[:5]:
        role_to_words[role].append(w)

# === Step 2: Infer proto-syntax templates ===
templates = []
if transitions:
    for t, prob in sorted(transitions.items(), key=lambda x: x[1], reverse=True)[:8]:
        a,b = t.split("->")
        if a in role_to_words and b in role_to_words:
            templates.append((a,b,prob))

# === Step 3: Generate candidate "proto-sentences" ===
proto_sentences = []
for a,b,prob in templates:
    wa = random.choice(role_to_words[a]) if role_to_words[a] else ""
    wb = random.choice(role_to_words[b]) if role_to_words[b] else ""
    if wa and wb:
        sentence = f"{wa} {wb}"
        proto_sentences.append({
            "template": f"{a}->{b}",
            "sentence": sentence,
            "syntactic_strength": round(prob*100,2)
        })

# === Step 4: Semantic resonance analysis ===
resonance_values = [c.get("resonance",0) for c in clusters if c.get("resonance")]
avg_res = round(sum(resonance_values)/max(1,len(resonance_values)),3)

summary = {
    "timestamp": datetime.datetime.now().isoformat(),
    "templates": len(templates),
    "proto_sentences": len(proto_sentences),
    "avg_resonance": avg_res
}

json.dump({"summary":summary,"proto_sentences":proto_sentences}, open(out_json,"w"), indent=2)

with open(out_txt,"w") as f:
    f.write(f"=== ForgeNet Linguistic Genesis Engine — {summary['timestamp']} ===\n")
    f.write(f"Average semantic resonance: {avg_res}\n")
    f.write(f"Templates discovered: {summary['templates']}\n")
    f.write("------------------------------------------------------------\n")
    for s in proto_sentences[:20]:
        f.write(f"[{s['template']:<12}]  {s['sentence']}  ({s['syntactic_strength']}%)\n")
    f.write("\n============================================================\n")

print(f"✅ Linguistic Genesis complete — {summary['proto_sentences']} proto-sentences generated")
print(f"🧩 Written → {out_json} and {out_txt}")
