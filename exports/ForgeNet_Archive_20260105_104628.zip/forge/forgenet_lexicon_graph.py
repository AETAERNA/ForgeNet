#!/data/data/com.termux/files/usr/bin/python
import os, json, math, datetime, itertools, collections

print("=== ForgeNet Decode Engine — Phase 3: Lexicon Evolution Graph (Pure Python Edition) ===")

base = os.path.expanduser("~/forge")
drift_path = os.path.join(base, "forgenet_semantic_drift.json")
crea_path  = os.path.join(base, "forgenet_creativity_timeline.json")
out_graph  = os.path.join(base, "forgenet_lexicon_graph.json")
out_ascii  = os.path.join(base, "forgenet_lexicon_ascii.txt")

# --- Load data ---
if not os.path.exists(drift_path):
    print("⚠️  No drift data — run Phase 2 first.")
    exit(0)

drift = json.load(open(drift_path))
crea  = json.load(open(crea_path)) if os.path.exists(crea_path) else []

# --- Build simple connectivity map ---
edges = []
nodes = collections.defaultdict(set)

for fam in drift["semantic_drifts"]:
    forms = fam["forms"]
    for a, b in itertools.combinations(forms, 2):
        weight = fam["drift"]
        edges.append((a, b, weight))
        nodes[a].add(b)
        nodes[b].add(a)

# --- Creativity weighting ---
cre_factor = 1.0
if crea:
    ci_vals = [c.get("creative_index", 0) for c in crea]
    if ci_vals:
        cre_factor = max(ci_vals) / (sum(ci_vals) / len(ci_vals))

edges_data = []
for a, b, w in edges:
    edges_data.append({"a": a, "b": b, "weight": round(w * cre_factor, 3)})

# --- Centrality (connectivity count) ---
central = {n: len(v) for n, v in nodes.items()}
top_nodes = sorted(central.items(), key=lambda x: -x[1])[:10]

# --- Write outputs ---
with open(out_graph, "w") as f:
    json.dump({
        "timestamp": str(datetime.datetime.now()),
        "nodes": len(nodes),
        "edges": len(edges),
        "top_nodes": top_nodes,
        "edges_data": edges_data
    }, f, indent=2)

lines = []
lines.append(f"Lexicon Evolution Graph  —  {len(nodes)} nodes / {len(edges)} edges")
lines.append("="*60)
for n, c in top_nodes:
    lines.append(f"{n:15} | connections={c}")
open(out_ascii, "w").write("\n".join(lines))

print(f"✅ Lexicon graph written → {out_graph}")
print(f"🧩 ASCII summary → {out_ascii}")
print("==============================================================")
