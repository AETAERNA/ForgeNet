#!/data/data/com.termux/files/usr/bin/python
import csv, math, os

path = os.path.expanduser("~/forge/forgenet_master.csv")
if not os.path.exists(path):
    print("⚠️  No dataset found.")
    exit()

h1, h2 = [], []
with open(path) as f:
    r = csv.reader(f)
    next(r)
    for row in r:
        try:
            h1.append(float(row[1]))
            h2.append(float(row[2]))
        except: pass

print("📊 ASCII Entropy Trend (h1,h2):")
for i in range(len(h1)):
    bar1 = '█' * int(h1[i])
    bar2 = '░' * int(h2[i]) if h2[i] > 0 else ''
    print(f"{i:02d} | {bar1}{bar2} ({h1[i]:.3f}, {h2[i]:.3f})")

try:
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (600, 200), "white")
    draw = ImageDraw.Draw(img)
    for i, (a,b) in enumerate(zip(h1,h2)):
        draw.rectangle([(i*6, 200-int(a*40)), (i*6+4, 200)], fill="black")
        draw.rectangle([(i*6, 200-int(b*40)), (i*6+4, 200)], fill="gray")
    img.save(os.path.expanduser("~/forge/entropy_plotlite.png"))
    print("✅ PNG plot saved → ~/forge/entropy_plotlite.png")
except:
    print("Pillow not found — run `pip install pillow` for PNG output.")
