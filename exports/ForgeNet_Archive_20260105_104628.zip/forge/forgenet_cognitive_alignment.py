#!/data/data/com.termux/files/usr/bin/python
import os, re, json, datetime, itertools
from collections import Counter, defaultdict

base = os.path.expanduser("~/forge")
semantic_file = os.path.join(base, "forgenet_semantic_resonance.json")
voynich_dir = os.path.join(base, "voynich_f17r_sim")
out_json = os.path.join(base, "forgenet_cognitive_alignment.json")
out_txt  = os.path.join(base, "forgenet_cognitive_alignment.txt")

# === Load semantic roles ===
if not os.path.exists(semantic_file):
    print("⚠️  Semantic resonance data missing — run semantic_resonance first.")
    exit()

sem_data = json.load(open(semantic_file))
clusters = sem_data.get("clusters", [])
role_map = {}
for c in clusters:
    for w in c.get("members", []):
        role_map[w] = c["dominant_role"]

# === Step 1: Read Voynich EVA files ===
if not os.path.exists(voynich_dir):
    print("⚠️  Voynich folder missing.")
    exit()

folios = [f for f in os.listdir(voynich_dir) if f.endswith(".txt")]
patterns = defaultdict(list)
transitions = Counter()

# === Step 2: Tokenize and align roles ===
for folio in folios:
    with open(os.path.join(voynich_dir, folio), "r", encoding="utf-8", errors="ignore") as fh:
        text = fh.read().lower()
    words = re.findall(r"[a-z]{4,}", text)
    roles = [role_map[w] if w in role_map else "unknown" for w in words]
    for (a,b) in itertools.pairwise(roles):
        transitions[(a,b)] += 1
    patterns[folio].extend(roles)

# === Step 3: Build transition probabilities ===
total = sum(transitions.values())
transition_probs = {f"{a}->{b}": round(c/total,4) for (a,b),c in transitions.items() if c>2}
sorted_transitions = sorted(transition_probs.items(), key=lambda x: x[1], reverse=True)

# === Step 4: Role ordering patterns per folio ===
folio_patterns = {}
for f, roles in patterns.items():
    seq = " ".join(r[0].upper() for r in roles if r != "unknown")
    common_seq = re.findall(r"[OPMC]{3,}", seq)  # O=object,P=process,M=modifier,C=connector
    counts = Counter(common_seq)
    folio_patterns[f] = counts.most_common(3)

# === Step 5: Save everything ===
summary = {
    "timestamp": datetime.datetime.now().isoformat(),
    "total_folios": len(folios),
    "transition_count": len(transition_probs),
    "dominant_sequences": sorted_transitions[:10]
}

json.dump({
    "summary": summary,
    "transitions": transition_probs,
    "folio_patterns": folio_patterns
}, open(out_json,"w"), indent=2)

with open(out_txt,"w") as f:
    f.write(f"=== ForgeNet Cognitive Alignment Engine — {summary['timestamp']} ===\n")
    f.write(f"Total folios analyzed: {summary['total_folios']}\n")
    f.write(f"Transition pairs: {summary['transition_count']}\n")
    f.write("------------------------------------------------------------\n")
    f.write("Top transition probabilities:\n")
    for k,v in sorted_transitions[:20]:
        f.write(f"  {k:20} {v}\n")
    f.write("\nMost common orderings per folio:\n")
    for fol, seqs in folio_patterns.items():
        f.write(f"  {fol}: {seqs}\n")
    f.write("\n============================================================\n")

print(f"✅ Cognitive Alignment complete — {summary['total_folios']} folios analyzed")
print(f"🧩 Written → {out_json} and {out_txt}")
