#!/data/data/com.termux/files/usr/bin/python
"""
ForgeNet Entropy Drift Tracker
Computes delta (Δh1, Δh2) between consecutive cycles.
"""
import csv, os
LOG = os.path.expanduser("~/forge/forgenet_master.csv")
OUT = os.path.expanduser("~/forge/forgenet_drift.csv")

rows = list(csv.DictReader(open(LOG)))
if len(rows) < 2:
    print("⚠️ Not enough data to compute drift.")
    exit(0)

with open(OUT,"w") as f:
    f.write("index,Δh1,Δh2\n")
    for i in range(1,len(rows)):
        dh1=float(rows[i]["h1"])-float(rows[i-1]["h1"])
        dh2=float(rows[i]["h2"])-float(rows[i-1]["h2"])
        f.write(f"{i},{dh1:.3f},{dh2:.3f}\n")
print(f"✅ Entropy drift written → {OUT}")
