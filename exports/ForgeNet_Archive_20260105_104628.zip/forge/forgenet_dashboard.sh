#!/data/data/com.termux/files/usr/bin/bash
# === ForgeNet Rolling Dashboard ===
LOG_DIR=~/forge/forgenet_logs
CSV=~/forge/forgenet_master.csv
VIS=~/forge/forgenet_visualizer.py
INTERVAL=600  # seconds = 10 minutes

echo "📊 ForgeNet Rolling Dashboard — monitoring entropy evolution..."
echo "Press Ctrl+C to stop."

while true; do
    echo
    echo "=== $(date '+%H:%M:%S') Updating dataset and chart ==="
    python "$VIS"
    if [ -f "$CSV" ]; then
        tail -n 5 "$CSV"
    fi
    bash ~/forge/voynich_f17r_sim/forge_heartbeat_notify.sh
    sleep $INTERVAL
done
