#!/data/data/com.termux/files/usr/bin/python
import os, json, math, datetime

print("=== ForgeNet Solver-Pilot — Unified Orchestration ===")

base = os.path.expanduser("~/forge")
paths = {
    "entropy": os.path.join(base, "forgenet_master.csv"),
    "drift":   os.path.join(base, "forgenet_semantic_drift.json"),
    "lexicon": os.path.join(base, "forgenet_lexicon_graph.json"),
    "creativity": os.path.join(base, "forgenet_creativity_timeline.json"),
}

out_path = os.path.join(base, "forgenet_solver_summary.txt")

# --- Load everything that exists ---
def safe_load(path, fmt="json"):
    if not os.path.exists(path):
        return None
    try:
        if fmt == "json": return json.load(open(path))
        else: return open(path).read().splitlines()
    except Exception as e:
        print(f"⚠️ Could not load {path}: {e}")
        return None

drift = safe_load(paths["drift"])
lex = safe_load(paths["lexicon"])
crea = safe_load(paths["creativity"])
entropy_lines = safe_load(paths["entropy"], fmt="csv")

# --- Compute a unified readiness score per folio ---
folios = {}

# entropy data
if entropy_lines:
    for line in entropy_lines[1:]:
        try:
            t, h1, h2 = line.split(",")
            folios[t] = {"entropy": float(h1), "cond": float(h2)}
        except: pass

# semantic drift weight
if drift:
    for fam in drift.get("semantic_drifts", []):
        for form in fam.get("forms", []):
            for f in folios.values():
                f["drift"] = f.get("drift", 0) + fam["drift"]/len(fam["forms"])

# lexicon centrality
if lex:
    for name, count in lex.get("top_nodes", []):
        for f in folios.values():
            f["centrality"] = f.get("centrality", 0) + count/10

# creativity pulse
cre_factor = 1.0
if crea:
    ci = [c.get("creative_index", 0) for c in crea if c.get("creative_index", 0)]
    if ci: cre_factor = max(ci)/(sum(ci)/len(ci))

# --- Final ranking ---
results = []
for fol, vals in folios.items():
    readiness = (
        (vals.get("entropy",0)-vals.get("cond",0))*1.2
        + vals.get("drift",0)*0.8
        + vals.get("centrality",0)*0.6
    ) * cre_factor
    results.append((fol, round(readiness,3)))

results.sort(key=lambda x:-x[1])

# --- Write summary ---
lines = []
lines.append("=== ForgeNet Solver-Pilot Summary ===")
lines.append(f"Run time: {datetime.datetime.now()}")
lines.append(f"Creativity factor: {cre_factor:.3f}")
lines.append("")
lines.append(f"{'Folio':20} Readiness")
lines.append("="*35)
for f, r in results[:20]:
    lines.append(f"{f:20} {r:.3f}")
lines.append("")
lines.append("Interpretation:")
lines.append("High readiness → likely coherent segment for decryption/semantic mapping.")
lines.append("Low readiness → chaotic or filler zone (ritual noise).")

open(out_path,"w").write("\n".join(lines))

print(f"✅ Solver summary written → {out_path}")
print("==============================================================")
