#!/data/data/com.termux/files/usr/bin/bash
echo "🔄 Resetting Forge environment..."
tmux kill-server 2>/dev/null
pkill -f "python - <<'PYCODE'" 2>/dev/null
echo "✅ All sessions and hanging Python processes cleared."
cd ~/forge/voynich_f17r_sim
echo "System back online at $(date)"
