#!/data/data/com.termux/files/usr/bin/python
import os, csv, statistics

path = os.path.expanduser("~/forge/forgenet_master.csv")
if not os.path.exists(path):
    print("⚠️ No master CSV found.")
    exit()

data = []
with open(path) as f:
    r = csv.reader(f)
    next(r)
    for row in r:
        if len(row) >= 3:
            data.append((row[0], float(row[1]), float(row[2])))

if len(data) < 2:
    print("⚠️ Not enough entries to calculate drift.")
    exit()

drift = [abs(data[i+1][1]-data[i][1]) + abs(data[i+1][2]-data[i][2]) for i in range(len(data)-1)]
mean_drift = statistics.mean(drift)
print(f"🌊 Mean cross-entropy drift per cycle: {mean_drift:.4f}")

txt = os.path.expanduser("~/forge/forgenet_drift_report.txt")
open(txt,"w").write(f"Mean Drift: {mean_drift:.4f}\nAll drifts: {drift}\n")
print(f"✅ Written → {txt}")
