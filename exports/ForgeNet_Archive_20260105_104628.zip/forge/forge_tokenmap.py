#!/data/data/com.termux/files/usr/bin/python
"""
Forge Token Map
Counts dominant EVA tokens in each folio text.
"""
import re, os, collections

FOLIOS = ["f78r","f79v","f80r","f82v","f83r","f84r","f1r"]
OUT = os.path.expanduser("~/forge/tokenmap_summary.txt")

def count_tokens(file):
    if not os.path.isfile(file):
        return {}
    text = open(file).read().lower()
    tokens = re.findall(r"[a-z]+", text)
    c = collections.Counter(tokens)
    return dict(c.most_common(10))

with open(OUT, "w") as out:
    for f in FOLIOS:
        eva = os.path.expanduser(f"~/forge/voynich_f17r_sim/{f}_eva.txt")
        data = count_tokens(eva)
        if data:
            out.write(f"== {f} ==\n")
            for token, n in data.items():
                out.write(f"{token:10s} {n}\n")
            out.write("\n")
print(f"✅ Token frequency map saved → {OUT}")
