#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# 🚀 ForgeNet Autonomous Cycle — Full System Integration
# ============================================================

echo "🚀 ForgeNet Autonomous Cycle — Linguistic + Entropy Integration Run"
cd ~/forge/voynich_f17r_sim

# --- Update entropy datasets ---
echo "=== Updating datasets ==="
python ~/forge/forgenet_visualizer.py

# --- Generate word heatmap ---
echo "=== Heatmap of top recurring words ==="
python ~/forge/forgenet_heatmap.py

# --- Entropy status preview ---
echo "=== Latest Entropy Status ==="
tail -n 3 ~/forge/forgenet_master.csv

# --- Quick live entropy wave ---
echo "=== Starting Live Entropy Monitor (Ctrl+C to exit) ==="
python ~/forge/entropy_wave.py & sleep 3; pkill -f entropy_wave.py

# --- Visual entropy plot (matplotlib or plotlite fallback) ---
echo "=== Generating Visual Entropy Chart ==="
if python -c "import matplotlib" 2>/dev/null; then
    echo "Matplotlib detected — generating full plot"
    python ~/forge/forgenet_visualizer.py
else
    echo "Matplotlib not found — using Plotlite fallback"
    python ~/forge/forgenet_plotlite.py
fi

# --- Linguistic search integration ---
echo "=== Running ForgeSearch Linguistic Analyzer ==="
python ~/forge/forgenet_search.py

# --- Send notification heartbeat ---
bash ~/forge/voynich_f17r_sim/forge_heartbeat_notify.sh

# --- Wrap up ---
echo "✅ Forge cycle complete — entropy + linguistic systems synchronized."
echo "📊 Outputs:"
echo "  • ~/forge/entropy_plotlite.png (entropy graph)"
echo "  • ~/forge/forgenet_search_results.csv / .png (linguistic stem frequencies)"
echo "  • ~/forge/forgenet_master.csv (entropy dataset)"
echo "  • ~/forge/forgenet_heatmap.txt (repetition heatmap)"
echo "=============================================================="
