#!/data/data/com.termux/files/usr/bin/python
import os, json, statistics, datetime

memory_path = os.path.expanduser("~/forge/forge_memory.json")
log_path = os.path.expanduser("~/forge/forgenet_reflective_log.txt")

def trend_direction(values):
    if len(values) < 3:
        return "neutral"
    diffs = [values[i+1]-values[i] for i in range(len(values)-1)]
    avg = statistics.mean(diffs)
    if avg > 0.05:
        return "rising"
    elif avg < -0.05:
        return "falling"
    return "stable"

if not os.path.exists(memory_path):
    print("⚠️ No memory data found.")
    exit(0)

with open(memory_path) as f:
    data = json.load(f)

h1_hist = data.get("avg_h1", [])
h2_hist = data.get("avg_h2", [])
spikes = data.get("entropy_spikes", [])
now = str(datetime.datetime.now())

# --- ANALYSIS ---
direction_h1 = trend_direction(h1_hist)
direction_h2 = trend_direction(h2_hist)
coherence = None
if len(h1_hist) and len(h2_hist):
    coherence = round(statistics.mean([h1 - h2 for h1, h2 in zip(h1_hist, h2_hist)]), 3)

# --- INTERPRETATION ---
if coherence is not None:
    if coherence < 1.0:
        signal = "🧩 Cipher system trending toward order — internal grammar coherence strengthening."
    elif coherence < 1.8:
        signal = "🌗 Moderate drift — steady ritual repetition with evolving substructure."
    else:
        signal = "⚡ Volatility increasing — possible new cipher rule or paradigm shift detected."
else:
    signal = "No sufficient entropy history to interpret."

summary = f"""
=== Forge Reflective Mind Insight — {now} ===
h1 trend: {direction_h1}
h2 trend: {direction_h2}
average coherence delta: {coherence}
entropy spikes recorded: {len(spikes)}
Interpretation: {signal}
==============================================
"""

print(summary.strip())

with open(log_path, "a") as log:
    log.write(summary)
