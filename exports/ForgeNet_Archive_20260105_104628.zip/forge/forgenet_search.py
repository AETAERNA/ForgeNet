#!/data/data/com.termux/files/usr/bin/python
import os, re, csv
from collections import Counter
from PIL import Image, ImageDraw, ImageFont

data_dir = os.path.expanduser("~/forge/voynich_f17r_sim")
output_csv = os.path.expanduser("~/forge/forgenet_search_results.csv")
output_png = os.path.expanduser("~/forge/forgenet_search_results.png")

# Define your Voynich stems of interest
targets = ["chedy", "shey", "shedy", "qokedy", "qokeedy", "otain", "ykedy", "daiin", "chor", "shol", "dol", "rol"]

print("🔍 ForgeSearch Engine — Voynich Stem Analyzer")
print("Scanning EVA files for key stems...\n")

results = []
global_counts = Counter()

for file in sorted(os.listdir(data_dir)):
    if file.endswith("_eva.txt"):
        with open(os.path.join(data_dir, file), "r", encoding="utf-8", errors="ignore") as f:
            text = f.read().lower()
        counts = Counter()
        for t in targets:
            counts[t] = len(re.findall(t, text))
            global_counts[t] += counts[t]
        total = sum(counts.values())
        results.append((file, total, *[counts[t] for t in targets]))

# Write CSV summary
header = ["file", "total"] + targets
with open(output_csv, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(header)
    for r in results:
        w.writerow(r)

print(f"✅ ForgeSearch CSV written → {output_csv}\n")

# Print quick summary
print("📊 Top Global Frequencies:")
for word, count in global_counts.most_common(10):
    print(f"{word:10} {count:5d}")

# Draw quick PNG visualization (optional)
try:
    width = 600
    height = 200
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    bar_width = int(width / len(global_counts))
    max_val = max(global_counts.values()) if global_counts else 1
    for i, (word, count) in enumerate(global_counts.most_common(len(global_counts))):
        bar_height = int((count / max_val) * (height - 20))
        draw.rectangle([(i * bar_width, height - bar_height), (i * bar_width + bar_width - 2, height)], fill="black")
        draw.text((i * bar_width + 2, height - 15), word[:3], fill="gray")
    img.save(output_png)
    print(f"✅ PNG visualization saved → {output_png}")
except Exception as e:
    print(f"⚠️ Pillow visualization skipped: {e}")

print("\nForgeSearch complete — Voynich stem mapping done.")
