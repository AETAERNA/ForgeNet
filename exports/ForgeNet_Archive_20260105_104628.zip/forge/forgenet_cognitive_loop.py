#!/data/data/com.termux/files/usr/bin/python
import os, json, datetime, statistics, random

memory_path = os.path.expanduser("~/forge/forge_memory.json")
reflect_log = os.path.expanduser("~/forge/forgenet_reflective_log.txt")
state_path = os.path.expanduser("~/forge/forge_cognitive_state.json")

# --- Load prior state ---
if os.path.exists(state_path):
    with open(state_path, "r") as f:
        state = json.load(f)
else:
    state = {"runs": 0, "stability_index": 1.0, "learning_rate": 0.2}

def parse_reflections():
    """Scan the reflective log for signal patterns."""
    if not os.path.exists(reflect_log):
        return []
    lines = open(reflect_log).read().splitlines()
    signals = []
    for line in lines:
        if "Cipher system trending toward order" in line:
            signals.append(1.0)
        elif "Moderate drift" in line:
            signals.append(0.0)
        elif "Volatility increasing" in line:
            signals.append(-1.0)
    return signals

signals = parse_reflections()
avg_signal = statistics.mean(signals) if signals else 0.0

# --- Learning rule (simple reinforcement) ---
state["runs"] += 1
stability = state["stability_index"]
rate = state["learning_rate"]

new_stability = stability + rate * avg_signal
new_stability = max(min(new_stability, 2.0), -2.0)  # clamp to [-2,2]
state["stability_index"] = round(new_stability, 3)

# Adapt learning rate slightly to oscillate less over time
state["learning_rate"] = round(max(0.05, rate * (0.99 + random.random() * 0.02)), 3)

# --- Interpret result ---
if new_stability > 1.2:
    verdict = "🧠 System coherence strengthening — predictive accuracy rising."
elif new_stability < -0.8:
    verdict = "⚡ Pattern instability detected — entropy response adapting."
else:
    verdict = "🌿 Neutral phase — steady pattern consolidation."

summary = f"""
=== Forge Cognitive Loop — {datetime.datetime.now()} ===
Avg signal from last reflections: {avg_signal:+.3f}
Stability index now: {new_stability:+.3f}
Learning rate: {state['learning_rate']}
Interpretation: {verdict}
========================================================
"""
print(summary.strip())

with open(state_path, "w") as f:
    json.dump(state, f, indent=2)

open(os.path.expanduser("~/forge/forgenet_cognitive_log.txt"), "a").write(summary)
