#!/data/data/com.termux/files/usr/bin/bash
# === Forge Intelligence (AHA-Expansion v1.0) ===
# Self-evolving loop to analyze, learn, adapt, and alert

cd ~/forge/voynich_f17r_sim || exit 1
RUNSTAMP=$(date +%Y%m%d_%H%M%S)
LOG=~/forge/forgenet_intel_${RUNSTAMP}.log

echo "🧬 Forge Intelligence Cycle — $RUNSTAMP" | tee -a "$LOG"

# 1. Detect new folios
NEW=$(find . -type f -name "*.eva.txt" -newer ~/forge/forgenet_master.csv 2>/dev/null | wc -l)
if [ "$NEW" -gt 0 ]; then
    echo "📂 Detected $NEW new folio(s); refreshing dataset…" | tee -a "$LOG"
    python ~/forge/forgenet_sync.py >> "$LOG" 2>&1
fi

# 2. Run the research core
bash ~/forge/forge_auto_research.sh >> "$LOG" 2>&1

# 3. Extract last h1/h2 drift
LAST=$(tail -n 1 ~/forge/forgenet_master.csv)
echo "🔍 Drift: $LAST" >> "$LOG"

# 4. Entropy trend analysis (detect big pattern shifts)
python - <<'PYCODE' >> "$LOG" 2>&1
import pandas as pd, os, numpy as np
path=os.path.expanduser("~/forge/forgenet_master.csv")
if os.path.exists(path):
    df=pd.read_csv(path)
    if len(df)>3:
        df["delta"]=df["h1"]-df["h2"]
        drift=df["delta"].diff().abs().mean()
        spike=df["delta"].diff().abs().max()
        if spike>1.0:
            print(f"⚠️ Entropy spike detected: Δavg={drift:.3f}, Δmax={spike:.3f}")
            open(os.path.expanduser("~/forge/forgenet_alert.txt"),"a").write(f"{pd.Timestamp.now()} spike {spike:.3f}\n")
        else:
            print(f"Stable: Δavg={drift:.3f}")
PYCODE

# 5. Adaptive interval scheduler (learns its own rhythm)
STATE=~/forge/forgenet_intel_state.txt
if [ -f "$STATE" ]; then
    LAST_INT=$(tail -n1 "$STATE")
else
    LAST_INT=1800
fi
NEW_INT=$(( LAST_INT / 2 + RANDOM % 900 + 900 ))
echo "$NEW_INT" > "$STATE"
echo "⏱ Next cycle in $NEW_INT seconds (~$((NEW_INT/60)) min)" | tee -a "$LOG"

# 6. Human-readable alert
if [ -f ~/forge/forgenet_alert.txt ]; then
    termux-notification --title "Forge AHA Alert" \
        --content "Entropy spike detected; check ~/forge/forgenet_alert.txt" --priority high
fi

# 7. Optional — schedule itself again (adaptive self-loop)
(termux-job-scheduler --job-id 43 --period-ms $((NEW_INT*1000)) --script ~/forge/forge_intelligence.sh) >/dev/null 2>&1
echo "✅ Forge Intelligence cycle complete — log: $LOG"
python ~/forge/forgenet_memory_engine.py >> ~/forge/forgenet_intel_memory.log 2>&1
python ~/forge/forgenet_reflective_mind.py >> ~/forge/forgenet_intel_reflect.log 2>&1
python ~/forge/forgenet_cognitive_loop.py >> ~/forge/forgenet_intel_cog.log 2>&1
python ~/forge/forgenet_linguistic_visualizer.py >> ~/forge/forgenet_autopilot.log 2>&1
python ~/forge/forgenet_genesis_interpreter.py >> ~/forge/forgenet_autopilot.log 2>&1
python ~/forge/forgenet_concordance.py >> ~/forge/forgenet_autopilot.log 2>&1
