#!/data/data/com.termux/files/usr/bin/python
import os, json, csv, datetime, statistics

memory_path = os.path.expanduser("~/forge/forge_memory.json")
master_path = os.path.expanduser("~/forge/forgenet_master.csv")
research_log = os.path.expanduser("~/forge/forgenet_research_log.txt")

# Load or initialize memory
if os.path.exists(memory_path):
    with open(memory_path, "r") as f:
        memory = json.load(f)
else:
    memory = {
        "runs": [],
        "high_entropy_clusters": [],
        "entropy_spikes": [],
        "avg_h1": [],
        "avg_h2": [],
        "last_update": None
    }

# Extract entropy info
if os.path.exists(master_path):
    with open(master_path) as f:
        reader = csv.DictReader(f)
        h1, h2 = [], []
        for row in reader:
            try:
                h1.append(float(row["h1"]))
                h2.append(float(row["h2"]))
            except Exception:
                continue
        if h1 and h2:
            avg_h1, avg_h2 = statistics.mean(h1), statistics.mean(h2)
            memory["avg_h1"].append(avg_h1)
            memory["avg_h2"].append(avg_h2)
            drift = abs(avg_h1 - avg_h2)
            if drift > 1.5:
                memory["entropy_spikes"].append({
                    "time": str(datetime.datetime.now()),
                    "delta": drift
                })

# Detect volatile clusters
if os.path.exists(research_log):
    with open(research_log, "r") as f:
        text = f.read()
        volatile = [line for line in text.splitlines() if "VOLATILE" in line]
        if volatile:
            memory["high_entropy_clusters"].append({
                "time": str(datetime.datetime.now()),
                "text": volatile[-1]
            })

# Append run info
memory["runs"].append(str(datetime.datetime.now()))
memory["last_update"] = str(datetime.datetime.now())

# Save
os.makedirs(os.path.expanduser("~/forge"), exist_ok=True)
with open(memory_path, "w") as f:
    json.dump(memory, f, indent=2)

print("🧠 Forge Memory updated successfully.")
print(f"Total runs recorded: {len(memory['runs'])}")
