#!/data/data/com.termux/files/usr/bin/python
import csv, os, sys
from collections import defaultdict

# Increase max CSV field size for large Voynich files
csv.field_size_limit(sys.maxsize)

summary_path = os.path.expanduser("~/forge/forgenet_research_summary.csv")

if not os.path.exists(summary_path):
    print("⚠️ No research summary found — run forgenet_research_assist.py first.")
    exit(1)

folios, h1s, h2s, doms = [], [], [], []
with open(summary_path, encoding="utf-8", errors="ignore") as f:
    reader = csv.DictReader(f)
    for row in reader:
        try:
            folios.append(row["folio"])
            h1s.append(float(row["h1"]))
            h2s.append(float(row["h2"]))
            doms.append(row["dominant_word"])
        except Exception as e:
            print(f"⚠️ Skipped line: {e}")

mapdata = defaultdict(list)
for folio, h1, h2, dom in zip(folios, h1s, h2s, doms):
    group = "stable" if abs(h1 - h2) < 0.5 else "volatile"
    delta = round(abs(h1 - h2), 3)
    mapdata[group].append((folio, dom, delta))

print("=== Forge Pattern Visualizer — Entropy-Word Overlay ===")
for group, items in mapdata.items():
    print(f"\n[{group.upper()} REGION] — {len(items)} folios")
    for folio, dom, delta in sorted(items, key=lambda x: -x[2])[:12]:
        bar = "█" * int(delta * 4)
        print(f"{folio:18} Δ{delta:4.2f} |{bar}| dominant: {dom}")
print("\n📊 Visualization complete — entropy-word correlation rendered.")
