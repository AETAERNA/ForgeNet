import os
#!/data/data/com.termux/files/usr/bin/python
import csv, time
from itertools import cycle

path = os.path.expanduser("~/forge/forgenet_master.csv")
frames = cycle("⢀⢂⢄⡀")

while True:
    h1s, h2s = [], []
    with open(path) as f:
        for row in csv.DictReader(f):
            h1s.append(float(row["h1"]))
            h2s.append(float(row["h2"]))
    if h1s:
        print(f"\r{next(frames)} h1={h1s[-1]:.3f}  h2={h2s[-1]:.3f}", end="")
    time.sleep(2)
