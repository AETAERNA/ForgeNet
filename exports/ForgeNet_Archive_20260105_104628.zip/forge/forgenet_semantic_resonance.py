#!/data/data/com.termux/files/usr/bin/python
import os, re, json, datetime, math
from collections import Counter

base = os.path.expanduser("~/forge")
mce_path = os.path.join(base, "forgenet_meaning_convergence.json")
out_json = os.path.join(base, "forgenet_semantic_resonance.json")
out_txt  = os.path.join(base, "forgenet_semantic_resonance.txt")

if not os.path.exists(mce_path):
    print("⚠️  Meaning Convergence data missing — run meaning_convergence first.")
    exit()

data = json.load(open(mce_path))
clusters = data.get("clusters", [])

# --- helper metrics ---
def rhythm_score(word):
    vowels = sum(c in "aeiou" for c in word)
    return round(vowels / max(1,len(word)),3)

def repetition_factor(word):
    groups = re.findall(r"(..)\1+", word)
    return round(len(groups)/max(1,len(word)/2),3)

def role_from_pattern(rhythm, rep, length, bias):
    if rhythm > 0.45 and rep < 0.1 and bias < 0.25:
        return "object"        # smoother, noun-like
    elif rhythm < 0.35 and rep > 0.2:
        return "process"       # rougher, verb-like
    elif bias > 0.35 and rhythm > 0.4:
        return "modifier"      # descriptive/adjective-like
    else:
        return "connector"     # structural / grammatical

results=[]
for c in clusters:
    members=c.get("members",[])
    if not members: continue
    scores=[]
    for w in members[:8]:
        r=rhythm_score(w)
        rep=repetition_factor(w)
        role=role_from_pattern(r,rep,len(w),c["phonetic_bias"])
        scores.append((w,r,rep,role))
    role_counts=Counter(r for _,_,_,r in scores)
    dom_role=role_counts.most_common(1)[0][0]
    resonance=round(sum(r+rep for _,r,rep,_ in scores)/len(scores),3)
    results.append({
        "signature":c["signature"],
        "dominant_role":dom_role,
        "resonance":resonance,
        "members":[w for w,_,_,_ in scores],
        "convergence":c["convergence"]
    })

summary={
    "timestamp":datetime.datetime.now().isoformat(),
    "avg_resonance":round(sum(r["resonance"] for r in results)/max(1,len(results)),3),
    "role_distribution":Counter(r["dominant_role"] for r in results)
}
json.dump({"summary":summary,"clusters":results},open(out_json,"w"),indent=2)

with open(out_txt,"w") as f:
    f.write(f"=== ForgeNet Semantic Resonance Layer — {summary['timestamp']} ===\n")
    f.write(f"Average resonance: {summary['avg_resonance']}\n")
    f.write(f"Role distribution: {dict(summary['role_distribution'])}\n")
    f.write("------------------------------------------------------------\n")
    for r in results[:25]:
        f.write(f"\nSignature: {r['signature']}\n")
        f.write(f"  Dominant role: {r['dominant_role']}\n")
        f.write(f"  Resonance: {r['resonance']} | Convergence: {r['convergence']}\n")
        f.write(f"  Members: {', '.join(r['members'])}\n")
    f.write("\n============================================================\n")

print(f"✅ Semantic Resonance complete — {len(results)} clusters")
print(f"🧩 Written → {out_json} and {out_txt}")
