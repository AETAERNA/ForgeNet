#!/data/data/com.termux/files/usr/bin/python
import os, csv, math, sys
from collections import defaultdict

# === Fix for huge Voynich data fields ===
csv.field_size_limit(sys.maxsize)

summary_path = os.path.expanduser("~/forge/forgenet_research_summary.csv")

if not os.path.exists(summary_path):
    print("⚠️ No research summary found — run forgenet_research_assist.py first.")
    exit(1)

entries = []
with open(summary_path, encoding="utf-8", errors="ignore") as f:
    reader = csv.DictReader(f)
    for row in reader:
        try:
            folio = row.get("folio", "")
            h1 = float(row.get("h1", 0))
            h2 = float(row.get("h2", 0))
            dom = row.get("dominant_word", "").strip()
            entries.append((folio, h1, h2, dom))
        except Exception as e:
            print(f"⚠️ Skipped malformed line: {e}")

if not entries:
    print("❌ No valid entries loaded — check your research summary file.")
    exit(1)

def distance(e1, e2):
    dh = math.sqrt((e1[1]-e2[1])**2 + (e1[2]-e2[2])**2)
    same_dom = 0.5 if e1[3]==e2[3] and e1[3] else 0
    return dh - same_dom

clusters = defaultdict(list)
threshold = 0.8

for e in entries:
    assigned = False
    for c in clusters:
        if distance(e, clusters[c][0]) < threshold:
            clusters[c].append(e)
            assigned = True
            break
    if not assigned:
        clusters[len(clusters)+1].append(e)

print("=== Forge Neural Insight — Voynich Family Clusters ===")
for i, members in clusters.items():
    folios = [m[0] for m in members if m[0]]
    avg_h1 = sum(m[1] for m in members)/len(members)
    avg_h2 = sum(m[2] for m in members)/len(members)
    doms = sorted(set(m[3] for m in members if m[3]))
    print(f"[Cluster {i:02d}] — {len(members)} folios | Avg h1={avg_h1:.3f}, h2={avg_h2:.3f}")
    print("   Dominant tokens:", ", ".join(doms)[:120])
    print("   Folios:", ", ".join(folios[:10]), "...")
print("\n🧩 Clustering complete — linguistic family map rendered.")
