#!/data/data/com.termux/files/usr/bin/python
import os, time, datetime, subprocess

base = os.path.expanduser("~/forge")
logfile = os.path.join(base, "forgenet_autopilot_log.txt")
interval = 1800  # 30 minutes

def log(msg):
    t = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{t}] {msg}"
    print(line)
    with open(logfile, "a") as f:
        f.write(line + "\n")

def run(cmd, desc):
    log(f"→ {desc}")
    try:
        subprocess.run(cmd, shell=True, check=True)
        log(f"✅ {desc} complete.")
    except subprocess.CalledProcessError as e:
        log(f"⚠️ {desc} failed: {e}")

log("=== ForgeNet Autopilot Loop v1 Initialized ===")

while True:
    cycle_time = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    log(f"🚀 New cycle {cycle_time} starting.")
    
    run("python ~/forge/forgenet_entropy_drift.py", "Entropy Drift update")
    run("python ~/forge/forgenet_solver_pilot.py", "Solver-Pilot orchestration")
    run("python ~/forge/forgenet_predictive_insight.py", "Predictive Insight forecast")
    
    log("🧠 Cognitive pulse chain complete.")
    log(f"🌙 Sleeping {interval/60:.0f} min before next cycle...")
    time.sleep(interval)
