#!/data/data/com.termux/files/usr/bin/python
import os, json, datetime, math, random
from collections import Counter, defaultdict

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_PLOT=True
except Exception:
    HAS_PLOT=False

base=os.path.expanduser("~/forge")
lge_path=os.path.join(base,"forgenet_linguistic_genesis.json")
cae_path=os.path.join(base,"forgenet_cognitive_alignment.json")
out_graph=os.path.join(base,"forgenet_linguistic_graph.png")
out_ascii=os.path.join(base,"forgenet_linguistic_graph.txt")

if not os.path.exists(lge_path) or not os.path.exists(cae_path):
    print("⚠️ Missing dependencies — run linguistic_genesis and cognitive_alignment first.")
    exit()

lge=json.load(open(lge_path))
cae=json.load(open(cae_path))

pairs=[(s["template"],s["sentence"],s["syntactic_strength"]) for s in lge["proto_sentences"]]
transitions=cae.get("transitions",{})

# === Build frequency maps ===
role_freq=Counter()
link_strength=defaultdict(float)
for t, sent, strength in pairs:
    role_freq[t]+=1
    link_strength[t]+=strength

# === ASCII map ===
lines=[]
lines.append("=== ForgeNet Linguistic Genesis Visualizer ===")
lines.append(f"Timestamp: {datetime.datetime.now().isoformat()}")
lines.append(f"Templates visualized: {len(pairs)}")
lines.append("------------------------------------------------------------")

for t,v in sorted(link_strength.items(),key=lambda x:x[1],reverse=True)[:15]:
    bar="█"*int(v/5)
    lines.append(f"{t:15} | {bar} {v:.2f}")

lines.append("\nRole occurrence distribution:")
for r,c in role_freq.most_common():
    lines.append(f"{r:15} : {c}")

open(out_ascii,"w").write("\n".join(lines))

# === Optional image plot ===
if HAS_PLOT and pairs:
    roles=list(link_strength.keys())
    vals=[link_strength[k] for k in roles]
    plt.figure(figsize=(8,5))
    plt.barh(range(len(roles)),vals)
    plt.yticks(range(len(roles)),roles)
    plt.xlabel("Cumulative syntactic strength (%)")
    plt.title("ForgeNet Linguistic Genesis — Syntax Connectivity")
    plt.tight_layout()
    plt.savefig(out_graph)
    print(f"✅ Graphical syntax map → {out_graph}")

print(f"✅ ASCII syntax map written → {out_ascii}")
print("============================================================")
