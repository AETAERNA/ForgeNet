#!/data/data/com.termux/files/usr/bin/bash
# === Forge Silent Autoloop ===
LOGFILE=~/forge/forge_autoloop.log
INTERVAL=$((60 * 60 * 3))  # 3 hours

echo "🕒 Forge Silent Autoloop started — $(date)" >> "$LOGFILE"

while true; do
    echo "▶️  $(date): Running autonomous Forge cycle..." >> "$LOGFILE"
    bash ~/forge/forge_relay.sh >> "$LOGFILE" 2>&1
    echo "✅  Cycle complete — sleeping for $INTERVAL seconds." >> "$LOGFILE"
    sleep $INTERVAL
done
bash ~/forge/forge_orchestrator.sh >> ~/forge/forge_autoloop.log 2>&1
