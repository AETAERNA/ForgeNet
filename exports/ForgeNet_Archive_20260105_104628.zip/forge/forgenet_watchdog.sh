#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
# 🔭 ForgeNet Watchdog — Autonomous Research Sync Daemon
# ============================================================
# Monitors ~/forge/voynich_f17r_sim and ~/forge/forgenet_logs
# When changes detected → runs forge_master.sh automatically
# ============================================================

WATCH_DIR1=~/forge/voynich_f17r_sim
WATCH_DIR2=~/forge/forgenet_logs
DEST_DIR=~/storage/shared/Documents/ForgeNet
INTERVAL=60  # check every 60 seconds
RUNNING_FLAG=/data/data/com.termux/files/home/.forgenet_running

echo "🔭 ForgeNet Watchdog initialized — monitoring for changes every ${INTERVAL}s"
mkdir -p "$DEST_DIR"

# --- Function: sync results to Documents ---
sync_results() {
    cp -u ~/forge/*.csv "$DEST_DIR" 2>/dev/null
    cp -u ~/forge/*.png "$DEST_DIR" 2>/dev/null
    echo "[Sync] Results updated → $DEST_DIR"
}

# --- Function: run the Forge cycle if idle ---
trigger_cycle() {
    if [ -f "$RUNNING_FLAG" ]; then
        echo "[Watchdog] Cycle already running, skipping..."
    else
        echo "[Watchdog] Change detected — launching Forge cycle..."
        touch "$RUNNING_FLAG"
        bash ~/forge/forge_master.sh
        rm -f "$RUNNING_FLAG"
        sync_results
        bash ~/forge/voynich_f17r_sim/forge_heartbeat_notify.sh
    fi
}

# --- Initial baseline hash ---
LAST_HASH1=$(find "$WATCH_DIR1" -type f -exec sha1sum {} + | sha1sum | cut -d' ' -f1)
LAST_HASH2=$(find "$WATCH_DIR2" -type f -exec sha1sum {} + | sha1sum | cut -d' ' -f1)

while true; do
    sleep $INTERVAL
    HASH1=$(find "$WATCH_DIR1" -type f -exec sha1sum {} + | sha1sum | cut -d' ' -f1)
    HASH2=$(find "$WATCH_DIR2" -type f -exec sha1sum {} + | sha1sum | cut -d' ' -f1)
    if [ "$HASH1" != "$LAST_HASH1" ] || [ "$HASH2" != "$LAST_HASH2" ]; then
        trigger_cycle
        LAST_HASH1=$HASH1
        LAST_HASH2=$HASH2
    fi
done
