#!/data/data/com.termux/files/usr/bin/python
"""
ForgeNet Correlation Analyzer
Finds correlation between token frequency and entropy (h1/h2) per folio.
"""
import csv, os, re, statistics

CROSSFOLIO = os.path.expanduser("~/forge/forgenet_crossfolio.csv")
TOKENMAP = os.path.expanduser("~/forge/tokenmap_summary.txt")
OUT = os.path.expanduser("~/forge/forgenet_correlation.txt")

def parse_crossfolio():
    data = {}
    if not os.path.isfile(CROSSFOLIO): return data
    for row in csv.DictReader(open(CROSSFOLIO)):
        data[row["folio"]] = (float(row["avg_h1"]), float(row["avg_h2"]))
    return data

def parse_tokenmap():
    tokens = {}
    current = None
    if not os.path.isfile(TOKENMAP): return tokens
    for line in open(TOKENMAP):
        line=line.strip()
        if line.startswith("=="):
            current = re.findall(r"f\d+[rv]", line)[0]
            tokens[current]={}
        elif line:
            parts=line.split()
            if len(parts)==2:
                token,count=parts
                tokens[current][token]=int(count)
    return tokens

def correlation(x,y):
    if len(x)<2: return 0.0
    xm, ym = statistics.mean(x), statistics.mean(y)
    num = sum((a-xm)*(b-ym) for a,b in zip(x,y))
    den = (sum((a-xm)**2 for a in x)*sum((b-ym)**2 for b in y))**0.5
    return num/den if den else 0.0

cf = parse_crossfolio()
tm = parse_tokenmap()

tokens_all = {}
for folio,toks in tm.items():
    for k,v in toks.items():
        tokens_all.setdefault(k,[]).append((folio,v))

with open(OUT,"w") as out:
    out.write("token,cor_h1,cor_h2\n")
    for token,pairs in tokens_all.items():
        folios=[f for f,_ in pairs if f in cf]
        if not folios: continue
        freq=[v for f,v in pairs if f in cf]
        h1=[cf[f][0] for f,v in pairs if f in cf]
        h2=[cf[f][1] for f,v in pairs if f in cf]
        out.write(f"{token},{correlation(freq,h1):.3f},{correlation(freq,h2):.3f}\n")

print(f"✅ Correlation map written → {OUT}")
