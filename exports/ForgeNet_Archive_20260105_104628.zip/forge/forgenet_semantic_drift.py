#!/data/data/com.termux/files/usr/bin/python
import os, json, re, math, datetime, collections

print("=== ForgeNet Decode Engine — Phase 2: Semantic Drift Inference ===")

decode_path = os.path.expanduser("~/forge/forgenet_decode_insight.json")
out_path = os.path.expanduser("~/forge/forgenet_semantic_drift.json")

if not os.path.exists(decode_path):
    print("⚠️ Decode insight missing — run phase 1 first.")
    exit(0)

data = json.load(open(decode_path))
tokens = [d["token"] for d in data["decode_hints"] if d["token"]]

# --- Group by shared roots ---
def normalize(word):
    return re.sub(r'(ch|sh|q|k|o|a|y)+$', '', word[:8])

groups = collections.defaultdict(list)
for t in tokens:
    root = normalize(t)
    groups[root].append(t)

# --- Measure entropy drift between related forms ---
def entropy(w):
    probs = [w.count(c)/len(w) for c in set(w)]
    return -sum(p*math.log2(p) for p in probs)

drifts = []
for root, forms in groups.items():
    if len(forms) < 2: continue
    e_vals = [entropy(f) for f in forms]
    drift = max(e_vals) - min(e_vals)
    drifts.append({
        "root": root,
        "forms": forms,
        "drift": round(drift, 3)
    })

drifts.sort(key=lambda x: -x["drift"])

with open(out_path, "w") as f:
    json.dump({
        "timestamp": str(datetime.datetime.now()),
        "semantic_drifts": drifts[:30]
    }, f, indent=2)

print(f"✅ Semantic drift map written → {out_path}")
print(f"🧭 {len(drifts)} drift families identified.")
print("==============================================================")
