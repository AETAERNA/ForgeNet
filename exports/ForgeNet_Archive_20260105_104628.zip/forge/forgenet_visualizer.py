#!/data/data/com.termux/files/usr/bin/python
import os, re, datetime, csv

LOG_DIR = os.path.expanduser("~/forge/forgenet_logs")
OUT_CSV = os.path.expanduser("~/forge/forgenet_master.csv")

entries = []
pattern = re.compile(r"h1=([0-9.]+).*?h2=([0-9.]+)", re.IGNORECASE)
import re

pattern = re.compile(
    r"Shannon entropy:\s*([0-9.]+).*?(?:Bigram\s+Conditional\s+h2\s+Entropy:\s*([0-9.]+))?",
    re.IGNORECASE | re.DOTALL
)
for log_file in sorted(os.listdir(LOG_DIR)):
    path = os.path.join(LOG_DIR, log_file)
    if os.path.isfile(path):
        with open(path) as f:
            content = f.read()
        match = pattern.search(content)
        if match:
            # Extract h1/h2 safely — fill 0.0 if missing
            h1 = float(match.group(1)) if match.group(1) else 0.0
            h2 = float(match.group(2)) if match.group(2) else 0.0

            # Extract timestamp from filename or fallback to now
            timestamp = (
                log_file.split("_")[1].split(".")[0]
                if "_" in log_file
                else datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            )

            entries.append((timestamp, h1, h2))
if not entries:
    print("⚠️ No valid entropy entries found in ForgeNet logs.")
    exit(0)

with open(OUT_CSV, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["timestamp", "h1", "h2"])
    w.writerows(entries)

print(f"✅ ForgeNet master dataset written → {OUT_CSV}")

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    t = [e[0] for e in entries]
    h1 = [e[1] for e in entries]
    h2 = [e[2] for e in entries]
    plt.figure(figsize=(10,5))
    plt.plot(h1, label="Shannon h1")
    plt.plot(h2, label="Conditional h2")
    plt.xlabel("Cycle Index")
    plt.ylabel("bits/char")
    plt.title("ForgeNet Entropy Evolution")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.expanduser("~/forge/entropy_evolution.png"))
    print("📊 Saved PNG → ~/forge/entropy_evolution.png")
except Exception as e:
    print("⚠️ Matplotlib not available — ASCII graph fallback:")
    import math
    for i, (ts, h1, h2) in enumerate(entries[-30:]):
        print(f"{i:02d} | h1={'█' * int(h1)} ({h1:.3f}) | h2={'█' * int(h2)} ({h2:.3f})")
