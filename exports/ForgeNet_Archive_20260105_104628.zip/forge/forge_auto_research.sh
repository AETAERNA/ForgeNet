#!/data/data/com.termux/files/usr/bin/bash
# === Forge Auto-Research System (FARS v1.0) ===
LOG=~/forge/forgenet_auto_research_$(date +%Y%m%d_%H%M%S).log
echo "🚀 Forge Auto-Research Run — $(date)" | tee -a "$LOG"

cd ~/forge/voynich_f17r_sim || exit 1

# Step 1 — Research Assist
echo "=== [1/3] Running Research Assist ===" | tee -a "$LOG"
python ~/forge/forgenet_research_assist.py >> "$LOG" 2>&1

# Step 2 — Pattern Visualizer
echo "=== [2/3] Running Pattern Visualizer ===" | tee -a "$LOG"
python ~/forge/forgenet_pattern_visualizer.py >> "$LOG" 2>&1

# Step 3 — Neural Insight (Clustering)
echo "=== [3/3] Running Neural Insight ===" | tee -a "$LOG"
python ~/forge/forgenet_neural_insight.py >> "$LOG" 2>&1

echo "✅ Forge Auto-Research cycle complete — log saved to:"
echo "   $LOG"
echo "🧠 Last 10 lines of log:" | tee -a "$LOG"
tail -n 10 "$LOG"
