#!/data/data/com.termux/files/usr/bin/python
import os, csv, json, math, statistics, re, collections, datetime

print("=== ForgeNet Decode Engine Scaffold — Phase 1 ===")

# === Paths ===
base = os.path.expanduser("~/forge")
entropy_path = os.path.join(base, "forgenet_master.csv")
creativity_path = os.path.join(base, "forgenet_creativity_timeline.json")
drift_path = os.path.join(base, "forgenet_drift_report.txt")
map_path = os.path.join(base, "forgenet_creativity_map.txt")
decode_out = os.path.join(base, "forgenet_decode_insight.json")

# === Data Loaders ===
def safe_load_json(path):
    if not os.path.exists(path): return []
    with open(path) as f:
        try: return json.load(f)
        except: return []

def safe_load_csv(path):
    if not os.path.exists(path): return []
    rows = []
    with open(path) as f:
        reader = csv.reader(f)
        header = next(reader, None)
        for r in reader: rows.append(r)
    return rows

# === Load all datasets ===
entropy = safe_load_csv(entropy_path)
creativity = safe_load_json(creativity_path)
drift = open(drift_path).read().splitlines() if os.path.exists(drift_path) else []
cremap = open(map_path).read().splitlines() if os.path.exists(map_path) else []

# === Decode Heuristic Engine ===
def word_entropy(word):
    probs = [word.count(c)/len(word) for c in set(word)]
    return -sum(p*math.log2(p) for p in probs)

tokens = [re.sub(r'[^a-z]', '', w.lower()) for line in cremap for w in line.split() if len(w) >= 4]
common = collections.Counter(tokens).most_common(200)

cre_index = [c["creative_index"] for c in creativity if "creative_index" in c]
entropy_vals = [float(e[1]) for e in entropy if len(e) > 1]

decode_hints = []
for w, count in common[:50]:
    we = word_entropy(w)
    align = (statistics.mean(cre_index) if cre_index else 0) * we
    decode_hints.append({
        "token": w,
        "self_entropy": round(we, 3),
        "alignment_score": round(align, 3),
        "frequency": count
    })

# === Write output ===
with open(decode_out, "w") as f:
    json.dump({
        "timestamp": str(datetime.datetime.now()),
        "decode_hints": decode_hints,
        "entropy_count": len(entropy),
        "creativity_points": len(creativity)
    }, f, indent=2)

print(f"✅ Decode insight written → {decode_out}")
print(f"🧩 {len(decode_hints)} token correlation hints extracted.")
print("============================================================")
