#!/data/data/com.termux/files/usr/bin/bash
clear
echo "=========================================="
echo "🌐  FORGEFLOW  ::  Adaptive Cycle Orchestrator"
echo "=========================================="
printf "Python: "; python --version
printf "Tmux:   "; tmux -V
echo "------------------------------------------"

PROJECT="$HOME/forge/voynich_f17r_sim"
cd "$PROJECT" 2>/dev/null || { echo "Project missing"; exit 1; }

echo "Running simulation engine..."
python sim_engine.py
echo "------------------------------------------"
echo "Running adaptive analysis..."
python adaptive_analysis.py
echo "------------------------------------------"

if [ -f adaptive_log.csv ]; then
  echo "Recent results:"
  tail -n 3 adaptive_log.csv
fi

echo "------------------------------------------"
echo "Syncing summary..." 
python ~/forge/voynich_f17r_sim/forge_ai_sync.py
python ~/forge/voynich_f17r_sim/forge_evolve.py
echo "✅  ForgeFlow adaptive cycle complete."
echo "Detach: Ctrl+b d   |  Reattach: tmux attach -t forge"
echo "=========================================="
