#!/data/data/com.termux/files/usr/bin/bash
echo "=========================================="
echo "🔁  FORGE AUTOCYCLE STARTED"
echo "Press Ctrl + C to stop."
echo "=========================================="
while true; do
    date
    bash ~/forge/forgeflow.sh
    echo "Sleeping 60 minutes..."
    sleep 3600    # change this value for a different interval
done
