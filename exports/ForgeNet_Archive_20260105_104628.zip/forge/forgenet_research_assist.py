#!/data/data/com.termux/files/usr/bin/python
import os, re, math, csv, datetime
from collections import Counter, defaultdict

base = os.path.expanduser("~/forge/voynich_f17r_sim")
log_path = os.path.expanduser("~/forge/forgenet_research_log.txt")

def shannon_entropy(text):
    freq = Counter(text)
    total = sum(freq.values())
    return -sum((c/total)*math.log2(c/total) for c in freq.values() if c)

def analyze_folio(file_path):
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        text = re.sub(r"[^a-z]+", "", f.read().lower())
    if not text: return None
    h1 = shannon_entropy(text)
    bigrams = Counter(zip(text, text[1:]))
    h2 = 0.0
    for (a, b), count in bigrams.items():
        p_bigram = count / (len(text) - 1)
        p_a = text.count(a) / len(text)
        if p_a > 0:
            h2 -= p_bigram * math.log2(p_bigram / p_a)
    word_freq = Counter(re.findall(r"[a-z]+", text))
    dominant = word_freq.most_common(1)[0]
    return (os.path.basename(file_path), h1, h2, dominant[0], dominant[1])

entries = []
for fname in sorted(os.listdir(base)):
    if fname.endswith("_eva.txt"):
        result = analyze_folio(os.path.join(base, fname))
        if result:
            entries.append(result)

with open(os.path.expanduser("~/forge/forgenet_research_summary.csv"), "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["folio", "h1", "h2", "dominant_word", "count"])
    writer.writerows(entries)

# === Pattern clustering ===
clusters = defaultdict(list)
for folio, h1, h2, dom, count in entries:
    key = "stable" if abs(h1 - h2) < 0.5 else "volatile"
    clusters[key].append((folio, dom, count))

# === Generate human-readable insight ===
timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
with open(log_path, "a") as log:
    log.write(f"\n=== Research Assist Insight — {timestamp} ===\n")
    log.write(f"Total folios analyzed: {len(entries)}\n")
    for k, v in clusters.items():
        avg_entropy = sum(x[1] for x in entries) / len(entries)
        log.write(f"{k.upper()} cluster: {len(v)} folios — avg entropy {avg_entropy:.3f}\n")
        log.write("Dominant tokens: " + ", ".join(sorted(set(x[1] for x in v)))[:150] + "\n")
    log.write("Persistent high-entropy terms: " + ", ".join(
        sorted({x[3] for x in entries if x[1] > 3.9}))[:150] + "\n")
    log.write("Low-predictability (h1-h2>1.5) folios: " + ", ".join(
        [x[0] for x in entries if (x[1] - x[2]) > 1.5]) + "\n")
    log.write("=== End of Insight ===\n")

print("✅ Research summary written → ~/forge/forgenet_research_summary.csv")
print("🧠 Insight log appended → ~/forge/forgenet_research_log.txt")
