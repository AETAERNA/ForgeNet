#!/data/data/com.termux/files/usr/bin/bash
echo
echo "============================================================"
echo "🧬  FORGENET COGNITIVE DASHBOARD  ($(date '+%Y-%m-%d %H:%M:%S'))"
echo "============================================================"

# --- Entropy Summary ---
if [ -f ~/forge/forgenet_master.csv ]; then
    echo
    echo "📊  ENTROPY STATUS"
    tail -n 5 ~/forge/forgenet_master.csv
else
    echo "⚠️  Entropy dataset missing."
fi

# --- Creativity Summary ---
if [ -f ~/forge/forgenet_creativity_map.txt ]; then
    echo
    echo "🎨  CREATIVITY INDEX (Top 10)"
    head -n 15 ~/forge/forgenet_creativity_map.txt | tail -n 10
else
    echo "⚠️  Creativity map missing."
fi

# --- Drift Analysis ---
if [ -f ~/forge/forgenet_drift_report.txt ]; then
    echo
    echo "🌊  ENTROPY DRIFT REPORT"
    head -n 5 ~/forge/forgenet_drift_report.txt
else
    echo "⚠️  Drift report not found."
fi

# --- Cognitive Timeline ---
if [ -f ~/forge/forgenet_creativity_timeline.json ]; then
    echo
    echo "🕒  CREATIVITY TREND (recent folios)"
    jq 'to_entries | .[] | {folio: .key, entries: .value | length}' ~/forge/forgenet_creativity_timeline.json 2>/dev/null | head -n 20
else
    echo "⚠️  No creativity timeline yet."
fi

# --- Pulse Sync ---
echo
echo "🔍  SYSTEM PULSE CHECK"
bash ~/forge/forgenet_syncpulse.sh | grep -E '✅|⚠️|❌'

# --- Cognitive Interpretation ---
echo
echo "🧩  INTERPRETATION"
if grep -q "Mean Drift" ~/forge/forgenet_drift_report.txt 2>/dev/null; then
    DRIFT=$(grep "Mean Drift" ~/forge/forgenet_drift_report.txt | awk '{print $3}')
    if (( $(echo "$DRIFT < 0.02" | bc -l) )); then
        echo "🟢 Stable linguistic phase — internal rules consolidated."
    elif (( $(echo "$DRIFT < 0.08" | bc -l) )); then
        echo "🟡 Transitional phase — subtle rule mutation detected."
    else
        echo "🔴 Volatile creative phase — entropy divergence high, evolving actively."
    fi
else
    echo "⚠️  Drift metrics unavailable."
fi

echo
echo "============================================================"
echo "💾 Logs: forgenet_creativity.log | forgenet_drift_report.log | forgenet_syncpulse.log"
echo "============================================================"
