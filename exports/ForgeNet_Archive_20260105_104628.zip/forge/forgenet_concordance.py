#!/data/data/com.termux/files/usr/bin/python
import os, json, datetime, csv
from collections import defaultdict, Counter

base = os.path.expanduser("~/forge")
gen_path = os.path.join(base, "forgenet_genesis_interpreter.json")
out_csv  = os.path.join(base, "forgenet_concordance.csv")
out_txt  = os.path.join(base, "forgenet_concordance.txt")

if not os.path.exists(gen_path):
    print("⚠️  Genesis Interpreter output not found.")
    exit()

data = json.load(open(gen_path))
entries = data.get("interpretations", [])

# --- build concordance ---
word_data = defaultdict(lambda: {"count":0,"glosses":Counter()})
for e in entries:
    for w,g in zip(e["original"].split(), e["gloss"].split()):
        word_data[w]["count"] += 1
        word_data[w]["glosses"][g] += 1

# --- write CSV + readable file ---
with open(out_csv,"w",newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["token","count","top_gloss","all_glosses"])
    for w,info in sorted(word_data.items(), key=lambda x:-x[1]["count"]):
        top = info["glosses"].most_common(1)[0][0]
        gloss_summary = ", ".join(f"{g}:{c}" for g,c in info["glosses"].most_common())
        writer.writerow([w, info["count"], top, gloss_summary])

with open(out_txt,"w") as f:
    f.write(f"=== ForgeNet Concordance — {datetime.datetime.now().isoformat()} ===\n")
    f.write(f"Entries: {len(word_data)}\n\n")
    for w,info in sorted(word_data.items(), key=lambda x:-x[1]["count"])[:40]:
        top = info["glosses"].most_common(1)[0][0]
        f.write(f"{w:15} → {top:12}  ({info['count']}×)\n")
    f.write("\n============================================================\n")

print(f"✅ Concordance built — {len(word_data)} entries")
print(f"📘 CSV → {out_csv}")
print(f"🧾 Text summary → {out_txt}")
