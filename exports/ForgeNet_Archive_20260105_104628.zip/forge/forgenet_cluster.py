#!/data/data/com.termux/files/usr/bin/python
"""
ForgeNet Folio Clusterer
Groups folios by entropy similarity and shared tokens.
"""
import csv, math, os, re
from itertools import combinations

cf = os.path.expanduser("~/forge/forgenet_crossfolio.csv")
tm = os.path.expanduser("~/forge/tokenmap_summary.txt")

# Parse
folios = {}
for row in csv.DictReader(open(cf)):
    folios[row["folio"]] = (float(row["avg_h1"]), float(row["avg_h2"]))

tokens = {}
cur = None
for line in open(tm):
    line=line.strip()
    if line.startswith("=="): cur = re.findall(r"f\d+[rv]", line)[0]
    elif line and cur:
        parts=line.split()
        if len(parts)==2: tokens.setdefault(cur,set()).add(parts[0])

def sim(a,b):
    (h1a,h2a),(h1b,h2b)=folios[a],folios[b]
    edist = math.sqrt((h1a-h1b)**2+(h2a-h2b)**2)
    jaccard = len(tokens[a]&tokens[b]) / len(tokens[a]|tokens[b]) if tokens[a]|tokens[b] else 0
    return 1/(1+edist) * (0.5+0.5*jaccard)

pairs=[]
for a,b in combinations(folios,2):
    s=sim(a,b)
    if s>0.5:
        pairs.append((s,a,b))

pairs.sort(reverse=True)
OUT=os.path.expanduser("~/forge/forgenet_clusters.txt")
with open(OUT,"w") as f:
    for s,a,b in pairs:
        f.write(f"{a} ↔ {b}  sim={s:.3f}\n")
print(f"✅ Cluster map → {OUT}")
