#!/data/data/com.termux/files/usr/bin/bash
set -e

FORGE=~/forge
STAMP=$(date +"%Y%m%d_%H%M%S")
ARCHIVE=$FORGE/ForgeNet_Archive_$STAMP.zip
REPORT=$FORGE/ForgeNet_Final_Report_$STAMP.txt

echo "🔧  Finalizing ForgeNet environment..."
echo "🕒  Timestamp: $STAMP"
echo "------------------------------------------------------------" > $REPORT

# 1️⃣ Stop any running tmux sessions cleanly
echo "🧱  Checking for active tmux sessions..."
if tmux list-sessions >/dev/null 2>&1; then
    tmux list-sessions | awk -F: '{print $1}' | while read s; do
        echo "   🔻 Stopping session: $s"
        tmux kill-session -t "$s" 2>/dev/null || true
    done
else
    echo "   No active tmux sessions."
fi
echo "------------------------------------------------------------" >> $REPORT

# 2️⃣ Archive the forge workspace
echo "🗜️  Archiving forge directory..."
cd ~
zip -r -q "$ARCHIVE" forge >/dev/null
echo "✅  Archive created → $ARCHIVE"
echo "Archive: $ARCHIVE" >> $REPORT
echo "------------------------------------------------------------" >> $REPORT

# 3️⃣ Generate summary from key modules
echo "🧠  Summarizing ForgeNet datasets..." >> $REPORT
echo "" >> $REPORT

[[ -f $FORGE/forgenet_master.csv ]] && echo "📊 Entropy dataset: $(wc -l < $FORGE/forgenet_master.csv) lines" >> $REPORT
[[ -f $FORGE/forgenet_montecarlo.json ]] && echo "🎲 Monte Carlo samples: $(jq '.|length' $FORGE/forgenet_montecarlo.json 2>/dev/null)" >> $REPORT
[[ -f $FORGE/forgenet_creativity_log.txt ]] && echo "🎨 Creativity log: $(wc -l < $FORGE/forgenet_creativity_log.txt) entries" >> $REPORT
[[ -f $FORGE/forgenet_concordance.csv ]] && echo "📘 Lexicon entries: $(wc -l < $FORGE/forgenet_concordance.csv) tokens" >> $REPORT
[[ -f $FORGE/forgenet_semantic_matrix.txt ]] && echo "🧩 Semantic stability report attached." >> $REPORT
[[ -f $FORGE/forgenet_drift_report.txt ]] && echo "🌊 Entropy drift metrics available." >> $REPORT

echo "" >> $REPORT
echo "============================================================" >> $REPORT
echo "✅ ForgeNet Finalization Complete" >> $REPORT
echo "All processes stopped and datasets archived." >> $REPORT
echo "============================================================" >> $REPORT

echo "🧾  Report written → $REPORT"
