#!/data/data/com.termux/files/usr/bin/python
import os, json, datetime, math, random
from collections import defaultdict, Counter

base = os.path.expanduser("~/forge")
paths = {
    "lge": os.path.join(base, "forgenet_linguistic_genesis.json"),
    "srl": os.path.join(base, "forgenet_semantic_resonance.json"),
    "cae": os.path.join(base, "forgenet_cognitive_alignment.json"),
}
out_json = os.path.join(base, "forgenet_genesis_interpreter.json")
out_txt  = os.path.join(base, "forgenet_genesis_interpreter.txt")

# === Verify dependencies ===
for key, path in paths.items():
    if not os.path.exists(path):
        print(f"⚠️ Missing dependency: {key.upper()} data layer not found.")
        exit()

lge = json.load(open(paths["lge"]))
srl = json.load(open(paths["srl"]))
cae = json.load(open(paths["cae"]))

proto = lge.get("proto_sentences", [])
clusters = srl.get("clusters", [])
transitions = cae.get("transitions", {})

# === Build simplified lexicon ===
role_map = defaultdict(list)
for c in clusters:
    role = c.get("dominant_role","unknown")
    gloss = c.get("inferred_gloss", random.choice([
        "flow","growth","light","vessel","path","body","essence","cycle","union","motion","form","process"
    ]))
    for w in c.get("members",[])[:3]:
        role_map[w].append(gloss)

# === Synthesize glossed interpretations ===
interpretations = []
for s in proto:
    words = s["sentence"].split()
    glosses = []
    for w in words:
        if w in role_map:
            glosses.append(random.choice(role_map[w]))
        else:
            glosses.append(random.choice(["form","motion","entity","aspect","phase","element"]))
    human_line = " ".join(glosses)
    interpretations.append({
        "template": s["template"],
        "original": s["sentence"],
        "gloss": human_line,
        "strength": s["syntactic_strength"]
    })

# === Summaries ===
summary = {
    "timestamp": datetime.datetime.now().isoformat(),
    "entries": len(interpretations),
    "avg_strength": round(sum(i["strength"] for i in interpretations)/max(1,len(interpretations)),2),
    "dominant_roles": list(role_map.keys())[:10]
}

json.dump({"summary":summary,"interpretations":interpretations}, open(out_json,"w"), indent=2)

with open(out_txt,"w") as f:
    f.write(f"=== ForgeNet Genesis Interpreter — {summary['timestamp']} ===\n")
    f.write(f"Entries generated: {summary['entries']}\n")
    f.write(f"Average syntactic strength: {summary['avg_strength']}\n")
    f.write("------------------------------------------------------------\n")
    for i in interpretations[:25]:
        f.write(f"[{i['template']:<12}] {i['original']:<30} → {i['gloss']:<40} ({i['strength']}%)\n")
    f.write("============================================================\n")

print(f"✅ Genesis Interpreter complete — {summary['entries']} entries interpreted")
print(f"🧩 Written → {out_json} and {out_txt}")
