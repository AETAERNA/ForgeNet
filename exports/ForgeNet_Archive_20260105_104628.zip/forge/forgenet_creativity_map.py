#!/data/data/com.termux/files/usr/bin/python
import json, os, math, statistics

path = os.path.expanduser("~/forge/forgenet_montecarlo.json")
data = json.load(open(path))

scores = []
for f, vals in data.items():
    try:
        variability = vals["stdev_h1"] + vals["stdev_h2"]
        divergence = abs(vals["mean_h1"] - vals["mean_h2"])
        creativity = (variability + divergence) * 100
        scores.append((f, creativity, vals["mean_h1"], vals["mean_h2"]))
    except KeyError:
        continue

scores.sort(key=lambda x: x[1], reverse=True)

out_txt = os.path.expanduser("~/forge/forgenet_creativity_map.txt")
with open(out_txt,"w") as fh:
    fh.write("=== Forge Creativity Map ===\n")
    fh.write("folio\tcreativity_index\th1\t\th2\n")
    for f, c, h1, h2 in scores:
        fh.write(f"{f}\t{c:.2f}\t{h1:.3f}\t{h2:.3f}\n")

print(f"✅ Creativity map written → {out_txt}")

# ASCII scatter
print("\n🎨  Creativity-Entropy Scatter (top 15):")
for f, c, h1, h2 in scores[:15]:
    bar = "█" * int(min(50, c))
    print(f"{f[:10]:12} {bar} {c:.2f}")

# optional PNG if Pillow present
try:
    from PIL import Image, ImageDraw
    w, h = 600, 400
    im = Image.new("RGB",(w,h),"white")
    dr = ImageDraw.Draw(im)
    maxc = max(s[1] for s in scores)
    for i,(f,c,h1,h2) in enumerate(scores):
        x = int((i/len(scores))*w)
        y = int(h - (c/maxc)*h)
        dr.rectangle((x,y,x+2,h),fill="black")
    out_img = os.path.expanduser("~/forge/forgenet_creativity_map.png")
    im.save(out_img)
    print(f"🖼  PNG saved → {out_img}")
except Exception as e:
    print("⚠️  Pillow not available, PNG skipped.")
