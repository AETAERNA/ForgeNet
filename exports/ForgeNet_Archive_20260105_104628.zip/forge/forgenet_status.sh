#!/data/data/com.termux/files/usr/bin/bash
echo "=== ForgeNet Status $(date '+%H:%M:%S') ==="
tail -n 5 ~/forge/forgenet_master.csv
echo "--- Drift ---"
tail -n 3 ~/forge/forgenet_drift.csv
echo "--- Cross-Folio Summary ---"
tail -n 5 ~/forge/forgenet_crossfolio.csv
echo "--- Top Correlations ---"
head -n 10 ~/forge/forgenet_correlation.txt
