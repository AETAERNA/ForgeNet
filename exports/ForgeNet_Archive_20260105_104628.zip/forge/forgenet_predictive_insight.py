#!/data/data/com.termux/files/usr/bin/python
import os, json, random, datetime, math

print("=== ForgeNet Predictive Insight Engine (PIE) — Monte-Carlo Layer ===")

base = os.path.expanduser("~/forge")
solver_summary = os.path.join(base, "forgenet_solver_summary.txt")
lexicon = os.path.join(base, "forgenet_lexicon_graph.json")
out_path = os.path.join(base, "forgenet_predictive_forecast.txt")

# --- Load data ---
def parse_solver_summary(path):
    data = []
    if not os.path.exists(path):
        print("⚠️ Solver summary missing — run solver_pilot first.")
        return data
    with open(path) as f:
        for line in f:
            if "," in line or "===" in line or "Folio" in line: 
                continue
            parts = line.strip().split()
            if len(parts) == 2:
                folio, readiness = parts
                try:
                    data.append((folio, float(readiness)))
                except: pass
    return data

folios = parse_solver_summary(solver_summary)
lex = json.load(open(lexicon)) if os.path.exists(lexicon) else {}

# --- Monte-Carlo simulation ---
if not folios:
    print("⚠️ No folio data available. Exiting.")
    exit(0)

forecast = []
for _ in range(500):  # 500 random projections
    noise = random.uniform(-0.05, 0.05)
    choice = random.choices(folios, weights=[r for _,r in folios])[0]
    drift_influence = random.uniform(0.8, 1.2)
    future_score = choice[1] * drift_influence + noise
    forecast.append((choice[0], round(future_score, 3)))

# --- Aggregate predictions ---
rank = {}
for f, s in forecast:
    rank.setdefault(f, []).append(s)
summary = [(f, sum(v)/len(v), len(v)) for f,v in rank.items()]
summary.sort(key=lambda x:-x[1])

# --- Optional lexicon tie-in ---
top_tokens = []
if lex:
    for n, _ in lex.get("top_nodes", [])[:5]:
        top_tokens.append(n)

# --- Write output ---
lines = []
lines.append("=== ForgeNet Predictive Forecast ===")
lines.append(f"Run time: {datetime.datetime.now()}")
lines.append("")
lines.append(f"{'Folio':20} Pred.Score  Simulations")
lines.append("="*40)
for f, avg, count in summary[:15]:
    lines.append(f"{f:20} {avg:.3f}     ({count})")

lines.append("")
lines.append("📖 Top tokens to cross-reference:")
lines.append(", ".join(top_tokens) if top_tokens else "N/A")

lines.append("")
lines.append("🧠 Interpretation:")
lines.append("→ Highest predicted scores = most fertile zones for linguistic convergence.")
lines.append("→ Focus these next: first 3 folios in the list below.")
lines.append("")
lines.append("==============================================================")

open(out_path,"w").write("\n".join(lines))
print(f"✅ Predictive forecast written → {out_path}")
