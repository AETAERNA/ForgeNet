#!/data/data/com.termux/files/usr/bin/bash
set -e

FORGE=~/forge
LATEST_ARCHIVE=$(ls -t $FORGE/ForgeNet_Archive_*.zip 2>/dev/null | head -n 1)
STAMP=$(date +"%Y%m%d_%H%M%S")
RESTORE_DIR=$FORGE/ForgeNet_Restore_$STAMP
REPORT=$FORGE/ForgeNet_Restart_Report_$STAMP.txt

echo "🚀 ForgeNet Restart Utility"
echo "🕒 Timestamp: $STAMP"
echo "------------------------------------------------------------" > $REPORT

# 1️⃣ Locate latest archive
if [ -z "$LATEST_ARCHIVE" ]; then
    echo "⚠️  No archive found in $FORGE" | tee -a $REPORT
    exit 1
else
    echo "📦 Latest archive found: $LATEST_ARCHIVE" | tee -a $REPORT
fi

# 2️⃣ Restore from archive
mkdir -p "$RESTORE_DIR"
echo "📂 Restoring environment to: $RESTORE_DIR" | tee -a $REPORT
unzip -q "$LATEST_ARCHIVE" -d "$RESTORE_DIR" >/dev/null
echo "✅ Restore complete." | tee -a $REPORT

# 3️⃣ Reactivate scripts
echo "🔄 Reinitializing Forge subsystems..." | tee -a $REPORT
chmod +x $RESTORE_DIR/forge/*.sh 2>/dev/null || true
chmod +x $RESTORE_DIR/forge/*.py 2>/dev/null || true

# 4️⃣ Optionally start Autopilot + Watchdog if present
if [ -f "$RESTORE_DIR/forge/forge_master.sh" ]; then
    echo "🧭 Launching Forge Autopilot..." | tee -a $REPORT
    bash "$RESTORE_DIR/forge/forge_master.sh" &
else
    echo "⚠️  Autopilot script not found, skipping." | tee -a $REPORT
fi

if [ -f "$RESTORE_DIR/forge/forgenet_watchdog.sh" ]; then
    echo "👁️  Starting Watchdog service..." | tee -a $REPORT
    bash "$RESTORE_DIR/forge/forgenet_watchdog.sh" &
else
    echo "⚠️  Watchdog script not found, skipping." | tee -a $REPORT
fi

# 5️⃣ Verification Summary
echo "------------------------------------------------------------" | tee -a $REPORT
echo "✅ ForgeNet restarted successfully at: $STAMP" | tee -a $REPORT
echo "Environment restored to: $RESTORE_DIR" | tee -a $REPORT
echo "============================================================" | tee -a $REPORT
echo "🧾 Report written → $REPORT"
