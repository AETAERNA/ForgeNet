#!/data/data/com.termux/files/usr/bin/bash
echo "🚀 Forge Orchestrator Launch — $(date)"
LOGROOT=~/forge
DAILY="$LOGROOT/forge_daily_brief.txt"

cd "$LOGROOT/voynich_f17r_sim" || exit 1
echo "🧩 System paths verified."

# --- 1. Run core intelligence cycle ---
echo "🧠 Running Intelligence Core..."
bash ~/forge/forge_intelligence.sh

# --- 2. Run memory update ---
echo "💾 Updating Forge Memory..."
python ~/forge/forgenet_memory_engine.py

# --- 3. Reflection ---
echo "🔮 Reflective Mind analysis..."
python ~/forge/forgenet_reflective_mind.py

# --- 4. Cognition (learning update) ---
echo "🧬 Cognitive loop..."
python ~/forge/forgenet_cognitive_loop.py

# --- 5. Research assist refresh ---
echo "🔍 Research assist refresh..."
python ~/forge/forgenet_research_assist.py

# --- 6. Visualization snapshot ---
echo "📊 Generating visual summaries..."
python ~/forge/forgenet_plotlite.py

# --- 7. Summary output ---
echo "🧾 Compiling daily intelligence brief..."
{
    echo "=== Forge Daily Brief — $(date) ==="
    echo
    echo "[Memory Overview]"
    tail -n 5 ~/forge/forgenet_intel_memory.log 2>/dev/null
    echo
    echo "[Reflections]"
    tail -n 5 ~/forge/forgenet_reflective_log.txt 2>/dev/null
    echo
    echo "[Cognition]"
    tail -n 5 ~/forge/forgenet_cognitive_log.txt 2>/dev/null
    echo
    echo "[Entropy Trend]"
    tail -n 5 ~/forge/forgenet_master.csv 2>/dev/null
    echo
    echo "=================================================="
} > "$DAILY"

echo "✅ Daily brief written to $DAILY"
echo "Forge Orchestrator complete."

# ============================================================
# 🧠 ForgeNet Creative Intelligence Layer
# ============================================================
echo "🎨  Running Monte Carlo stability test..."
python ~/forge/forgenet_montecarlo.py >> ~/forge/forgenet_montecarlo.log 2>&1

echo "🌈  Generating creativity index map..."
python ~/forge/forgenet_creativity_map.py >> ~/forge/forgenet_creativity.log 2>&1

# Display quick summary if available
if [ -f ~/forge/forgenet_creativity_map.txt ]; then
    echo
    echo "=== Creativity Snapshot ==="
    tail -n 10 ~/forge/forgenet_creativity_map.txt
fi

# ============================================================
# 🌌 Post-Cycle Diagnostics
# ============================================================
python ~/forge/forgenet_creativity_timeline.py >> ~/forge/forgenet_creativity_timeline.log 2>&1
python ~/forge/forgenet_entropy_drift.py >> ~/forge/forgenet_drift_report.log 2>&1
bash ~/forge/forgenet_syncpulse.sh >> ~/forge/forgenet_syncpulse.log 2>&1
