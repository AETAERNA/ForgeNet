#!/data/data/com.termux/files/usr/bin/python
import os, time, datetime, re

base = os.path.expanduser("~/forge")
log_path = os.path.join(base, "forgenet_autopilot_log.txt")
out_ascii = os.path.join(base, "forgenet_autopilot_visual.txt")

def read_log(path):
    if not os.path.exists(path):
        return []
    lines = open(path).read().splitlines()
    return [l for l in lines if "complete" in l or "cycle" in l]

def extract_metrics(lines):
    cycles, entropy, solver, forecast = [], [], [], []
    for ln in lines:
        if "cycle" in ln and "starting" in ln:
            m = re.search(r"cycle (\d+_\d+)", ln)
            if m:
                cycles.append(m.group(1))
        elif "Entropy Drift update complete" in ln:
            entropy.append(len(entropy) + 1)
        elif "Solver-Pilot orchestration complete" in ln:
            solver.append(len(solver) + 1)
        elif "Predictive Insight forecast complete" in ln:
            forecast.append(len(forecast) + 1)
    return cycles, entropy, solver, forecast

def ascii_plot(label, data, max_len=50):
    if not data:
        return f"{label}: (no data)"
    max_val = max(data)
    norm = [int((v / max_val) * max_len) for v in data]
    bars = ["█" * n for n in norm]
    return f"{label} Trend:\n" + "\n".join(f"{i:02d} | {bar}" for i, bar in enumerate(bars, 1))

while True:
    print("=== ForgeNet Autopilot Visualization ===")
    lines = read_log(log_path)
    if not lines:
        print("⚠️  No log entries yet — waiting for Autopilot cycles...")
        time.sleep(60)
        continue

    cycles, entropy, solver, forecast = extract_metrics(lines)
    out_lines = []
    out_lines.append(f"=== ForgeNet Visualization Snapshot — {datetime.datetime.now()} ===")
    out_lines.append(f"Cycles recorded: {len(cycles)}")
    out_lines.append(ascii_plot("Entropy", entropy))
    out_lines.append(ascii_plot("Solver", solver))
    out_lines.append(ascii_plot("Forecast", forecast))
    out_lines.append("==============================================================")

    os.system("clear")
    print("\n".join(out_lines))
    open(out_ascii, "w").write("\n".join(out_lines))
    print("\n(Refreshing in 120s — Ctrl+C to stop)")
    time.sleep(120)
