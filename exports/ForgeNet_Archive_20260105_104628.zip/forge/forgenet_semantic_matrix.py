#!/data/data/com.termux/files/usr/bin/python
import os, csv, json, datetime
from collections import defaultdict
import math

base = os.path.expanduser("~/forge")
concord_path = os.path.join(base,"forgenet_concordance.csv")
prev_path = os.path.join(base,"forgenet_concordance_prev.csv")
matrix_path = os.path.join(base,"forgenet_semantic_matrix.csv")
report_path = os.path.join(base,"forgenet_semantic_matrix.txt")

if not os.path.exists(concord_path):
    print("⚠️  No concordance file yet — run the concordance builder first.")
    exit()

# --- rotate old file for comparison ---
if os.path.exists(concord_path):
    os.system(f"cp {concord_path} {prev_path}")

def read_concord(path):
    data = {}
    with open(path,"r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            data[row["token"]] = row["top_gloss"]
    return data

current = read_concord(concord_path)
previous = read_concord(prev_path) if os.path.exists(prev_path) else {}

stability_scores = {}
for token, gloss in current.items():
    if token in previous:
        stability_scores[token] = 1.0 if previous[token]==gloss else 0.0
    else:
        stability_scores[token] = 0.5  # new word

stability = round(sum(stability_scores.values())/len(stability_scores),3)

# --- export matrix ---
with open(matrix_path,"w",newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["token","gloss_now","gloss_prev","stability"])
    for t in sorted(current.keys()):
        writer.writerow([t, current.get(t,""), previous.get(t,""), stability_scores.get(t,0.0)])

with open(report_path,"w") as f:
    f.write(f"=== ForgeNet Semantic Alignment Matrix — {datetime.datetime.now().isoformat()} ===\n")
    f.write(f"Global stability index: {stability:.3f}\n\n")
    f.write("Top drift candidates (changed gloss):\n")
    for t,v in sorted(stability_scores.items(), key=lambda x:x[1])[:20]:
        if v < 1.0:
            f.write(f"  {t:15}  {previous.get(t,'?'):12} → {current.get(t,'?'):12}\n")
    f.write("\n============================================================\n")

print(f"✅ Semantic alignment matrix built — stability {stability:.3f}")
print(f"🧾 Written → {report_path}")
