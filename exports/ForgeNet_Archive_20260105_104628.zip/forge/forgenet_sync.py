#!/data/data/com.termux/files/usr/bin/python
import os, datetime, shutil

SRC = os.path.expanduser("~/forge/voynich_f17r_sim/entropy_autocycle.log")
DST = os.path.expanduser("~/forge/forgenet_logs")
os.makedirs(DST, exist_ok=True)

stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
target = os.path.join(DST, f"entropy_{stamp}.log")

if os.path.exists(SRC):
    shutil.copy2(SRC, target)
    print(f"[{stamp}] Synced to ForgeNet: {target}")
else:
    print("No entropy_autocycle.log found — skipping sync.")
