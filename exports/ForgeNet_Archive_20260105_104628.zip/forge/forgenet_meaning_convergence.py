#!/data/data/com.termux/files/usr/bin/python
import os, re, json, math, itertools, datetime
from collections import Counter, defaultdict

base = os.path.expanduser("~/forge")
research_log = os.path.join(base, "forgenet_research_log.txt")
out_json = os.path.join(base, "forgenet_meaning_convergence.json")
out_txt  = os.path.join(base, "forgenet_meaning_convergence.txt")

# === Utility ===
def cosine_similarity(a, b):
    sa, sb = set(a), set(b)
    return len(sa & sb) / math.sqrt(len(sa) * len(sb)) if sa and sb else 0

def phonetic_weight(token):
    """Basic consonant/vowel balancing weight"""
    vowels = sum(1 for c in token if c in "aeiou")
    cons   = sum(1 for c in token if c.isalpha()) - vowels
    return round(abs(cons - vowels) / max(1, len(token)), 3)

def phoneme_signature(token):
    """Simplified phoneme reduction"""
    return re.sub(r"(ch|sh|th|ph|ck)", "X", token)

# === Step 1: Extract tokens from prior research ===
if not os.path.exists(research_log):
    print("⚠️ No research log found — run research_assist first.")
    exit()

text = open(research_log, "r", encoding="utf-8", errors="ignore").read().lower()
tokens = re.findall(r"[a-z]{4,}", text)
counts = Counter(tokens)

# === Step 2: Cluster similar phonetic forms ===
clusters = defaultdict(list)
for t1 in counts:
    sig = phoneme_signature(t1)
    clusters[sig].append((t1, counts[t1]))

# === Step 3: Compute intra-cluster convergence ===
results = []
for sig, items in clusters.items():
    if len(items) < 2:
        continue
    sims = []
    for (a, _), (b, _) in itertools.combinations(items, 2):
        sims.append(cosine_similarity(a, b))
    avg_sim = round(sum(sims)/len(sims), 3) if sims else 0
    avg_len = round(sum(len(x[0]) for x in items)/len(items), 2)
    phw = sum(phonetic_weight(x[0]) for x in items)/len(items)
    convergence = round((avg_sim + (1 - phw)) / 2, 3)
    results.append({
        "signature": sig,
        "members": [x[0] for x in items],
        "avg_len": avg_len,
        "phonetic_bias": round(phw, 3),
        "similarity": avg_sim,
        "convergence": convergence
    })

# === Step 4: Output summaries ===
results.sort(key=lambda x: x["convergence"], reverse=True)
now = datetime.datetime.now().isoformat()

data = {
    "timestamp": now,
    "clusters": results[:100],
    "summary": {
        "avg_convergence": round(sum(r["convergence"] for r in results)/max(1, len(results)), 3),
        "total_clusters": len(results)
    }
}

open(out_json, "w").write(json.dumps(data, indent=2))
with open(out_txt, "w") as f:
    f.write(f"=== ForgeNet Meaning Convergence Engine — {now} ===\n")
    for r in results[:25]:
        f.write(f"\nSignature: {r['signature']}\n")
        f.write(f"  Members: {', '.join(r['members'][:10])}\n")
        f.write(f"  Convergence: {r['convergence']}\n")
        f.write(f"  Phonetic Bias: {r['phonetic_bias']} | AvgLen: {r['avg_len']}\n")
    f.write("\n=====================================================\n")
    f.write(f"Mean convergence: {data['summary']['avg_convergence']}\n")
    f.write(f"Total clusters: {data['summary']['total_clusters']}\n")

print(f"✅ Meaning Convergence complete — {len(results)} clusters")
print(f"🧩 Written to {out_json} and {out_txt}")
