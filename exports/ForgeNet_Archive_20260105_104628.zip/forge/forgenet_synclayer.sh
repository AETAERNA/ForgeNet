#!/data/data/com.termux/files/usr/bin/bash
# === Forge SyncLayer V2: nightly backup + Voynich search + auto-repair ===
SRC_DIR=~/forge
DEST_DIR=~/storage/shared/Documents/ForgeNet
BACKUP_DIR="$DEST_DIR/backup/$(date +%Y-%m-%d)"
INDEX_FILE="$DEST_DIR/voynich_index.txt"
LOG="$SRC_DIR/forgenet_synclayer.log"

echo "🕓 [$(date '+%H:%M:%S')] Forge SyncLayer V2 starting..." | tee -a "$LOG"
mkdir -p "$BACKUP_DIR"

# --- 1️⃣ Backup key data ---
find "$SRC_DIR" -maxdepth 2 -type f \( -name '*.csv' -o -name '*.png' -o -name '*.txt' -o -name '*.log' \) \
  -exec cp {} "$BACKUP_DIR"/ \; 2>/dev/null
echo "✅ Backup complete → $BACKUP_DIR" | tee -a "$LOG"

# --- 2️⃣ Compress backups older than 3 days ---
find "$DEST_DIR/backup" -mindepth 1 -maxdepth 1 -type d -mtime +3 \
  -exec tar -czf {}.tar.gz {} --remove-files \; 2>/dev/null
echo "📦 Old backups compressed" | tee -a "$LOG"

# --- 3️⃣ Rebuild Voynich search index ---
echo "🔍 Rebuilding search index..." | tee -a "$LOG"
> "$INDEX_FILE"
find "$SRC_DIR/voynich_f17r_sim" -type f -name '*.txt' | while read f; do
    echo "[ $(basename "$f") ]" >> "$INDEX_FILE"
    grep -Eo '[a-z]+' "$f" | sort | uniq -c | sort -nr | head -n 20 >> "$INDEX_FILE"
    echo >> "$INDEX_FILE"
done
echo "✅ Index updated → $INDEX_FILE" | tee -a "$LOG"

# --- 4️⃣ Maintenance cleanup ---
find "$SRC_DIR" -type f -name '*.tmp' -delete 2>/dev/null
echo "🧹 Temporary files cleared" | tee -a "$LOG"

# --- 5️⃣ Integrity self-check ---
MISSING=0
for f in "$SRC_DIR"/forgenet_visualizer.py "$SRC_DIR"/forgenet_watchdog.sh; do
  [ -f "$f" ] || { echo "⚠️ Missing $f → recreating stub" | tee -a "$LOG"; echo "#!/bin/bash" > "$f"; chmod +x "$f"; MISSING=1; }
done
[ $MISSING -eq 0 ] && echo "✅ Integrity check OK" | tee -a "$LOG"

echo "🌙 SyncLayer V2 run finished — all systems updated." | tee -a "$LOG"
python ~/forge/forgenet_research_assist.py >> ~/forge/forgenet_research_log.txt 2>&1
