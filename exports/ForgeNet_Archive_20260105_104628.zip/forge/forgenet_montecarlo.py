#!/data/data/com.termux/files/usr/bin/python
import os, random, math, re, statistics, json

data_dir = os.path.expanduser("~/forge/voynich_f17r_sim")
samples = 5000   # number of Monte Carlo draws
window  = 500    # characters per draw

def shannon_entropy(text):
    freq = {}
    for ch in text:
        freq[ch] = freq.get(ch,0)+1
    total = len(text)
    return -sum((c/total)*math.log2(c/total) for c in freq.values())

def conditional_entropy(text):
    bigrams = {}
    for i in range(len(text)-1):
        pair = text[i:i+2]
        bigrams[pair] = bigrams.get(pair,0)+1
    total = len(bigrams)
    if total == 0: return 0.0
    return -sum((c/total)*math.log2(c/total) for c in bigrams.values())

files = [f for f in os.listdir(data_dir) if f.endswith(".txt")]
summary = {}

for f in files:
    path = os.path.join(data_dir, f)
    try:
        txt = re.sub(r'[^a-z]', '', open(path,encoding='utf-8',errors='ignore').read().lower())
        if len(txt) < window: continue
        h1_vals, h2_vals = [], []
        for _ in range(samples):
            start = random.randint(0, len(txt)-window)
            seg = txt[start:start+window]
            h1_vals.append(shannon_entropy(seg))
            h2_vals.append(conditional_entropy(seg))
        summary[f] = {
            "mean_h1": statistics.mean(h1_vals),
            "stdev_h1": statistics.stdev(h1_vals),
            "mean_h2": statistics.mean(h2_vals),
            "stdev_h2": statistics.stdev(h2_vals)
        }
        print(f"{f:20} h1={summary[f]['mean_h1']:.3f}±{summary[f]['stdev_h1']:.3f}  "
              f"h2={summary[f]['mean_h2']:.3f}±{summary[f]['stdev_h2']:.3f}")
    except Exception as e:
        print(f"[skip] {f}: {e}")

out = os.path.expanduser("~/forge/forgenet_montecarlo.json")
json.dump(summary, open(out,"w"), indent=2)
print(f"\n✅ Monte Carlo summary written → {out}")
