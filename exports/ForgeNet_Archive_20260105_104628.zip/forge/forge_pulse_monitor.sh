#!/bin/bash
CSV="$HOME/forge/forgenet_master.csv"
echo "Forge Pulse Monitor started — checking entropy plateau every 10 min"
while true; do
    if [ -f "$CSV" ]; then
        LAST5=$(tail -n 5 "$CSV" | cut -d',' -f2 | tr -d ' ' | sort | uniq)
        if [ "$(echo "$LAST5" | wc -l)" -eq 1 ]; then
            termux-notification --title "FORGE PLATEAU" --content "Entropy flat — load new folio?" --vibrate 500
            termux-toast "Plateau detected — time for new text?"
            echo "[$(date)] Plateau alert sent"
        fi
    fi
    sleep 600
done
