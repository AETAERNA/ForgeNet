#!/data/data/com.termux/files/usr/bin/python
"""
ForgeNet Cross-Folio Entropy Comparator
Reads entropy_* logs in ~/forge/forgenet_logs,
extracts h1/h2 per folio, and summarizes averages.
ASCII output fallback safe for Termux.
"""
import os, re, statistics

LOG_DIR = os.path.expanduser("~/forge/forgenet_logs")
OUT_CSV = os.path.expanduser("~/forge/forgenet_crossfolio.csv")

pattern = re.compile(
    r"f(\d+[rv])|Shannon entropy:\s*([0-9.]+)|Bigram Conditional h2 Entropy:\s*([0-9.]+)"
)

folios = {}
for file in sorted(os.listdir(LOG_DIR)):
    path = os.path.join(LOG_DIR, file)
    if not os.path.isfile(path):
        continue
    with open(path) as f:
        text = f.read()
    current_folio = None
    h1, h2 = None, None
    for m in pattern.finditer(text):
        folio, h1_match, h2_match = m.groups()
        if folio:
            current_folio = folio
        if h1_match:
            h1 = float(h1_match)
        if h2_match:
            h2 = float(h2_match)
    if current_folio:
        folios.setdefault(current_folio, []).append((h1 or 0.0, h2 or 0.0))

with open(OUT_CSV, "w") as f:
    f.write("folio,avg_h1,avg_h2,n\n")
    for folio, values in folios.items():
        h1s, h2s = zip(*values)
        avg_h1 = statistics.mean(h1s)
        avg_h2 = statistics.mean(h2s)
        f.write(f"{folio},{avg_h1:.3f},{avg_h2:.3f},{len(values)}\n")

print(f"✅ Cross-folio summary written → {OUT_CSV}")

# ASCII chart fallback
print("\n📊 Cross-Folio Entropy Map")
for folio, values in sorted(folios.items()):
    h1s, h2s = zip(*values)
    avg_h1 = statistics.mean(h1s)
    avg_h2 = statistics.mean(h2s)
    bar_h1 = "█" * int(avg_h1)
    bar_h2 = "░" * int(avg_h2)
    print(f"{folio:>6} | h1 {avg_h1:4.3f} {bar_h1} | h2 {avg_h2:4.3f} {bar_h2}")
