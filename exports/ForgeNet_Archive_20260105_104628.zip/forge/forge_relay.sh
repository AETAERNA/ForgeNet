#!/data/data/com.termux/files/usr/bin/bash
# === Forge Live Command Relay ===
clear
echo "⚙️  Initiating Forge Command Relay..."
bash ~/forge/forge_orchestrator.sh

BRIEF=~/forge/forge_daily_brief.txt

if [ -f "$BRIEF" ]; then
    echo
    echo "=== 🔍 Forge Daily Intelligence Brief ==="
    cat "$BRIEF" | tail -n 40
    echo "========================================="
    echo
    if command -v termux-tts-speak >/dev/null 2>&1; then
        echo "🗣  Speaking summary..."
        termux-tts-speak "Forge Orchestrator complete. Daily intelligence brief generated."
    else
        echo "🔇 termux-tts-speak not available. Install termux-api if you want voice feedback."
    fi
else
    echo "⚠️  No daily brief found."
fi

echo "✅ Forge Relay execution finished — $(date)"
