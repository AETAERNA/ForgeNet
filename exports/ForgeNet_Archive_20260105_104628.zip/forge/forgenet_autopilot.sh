#!/data/data/com.termux/files/usr/bin/bash
echo "🚀 ForgeNet Autonomous Cycle — All Systems Run"
while true; do
    echo "=== $(date '+%H:%M:%S') Updating ==="
    python ~/forge/forgenet_visualizer.py
    python ~/forge/forgenet_crossfolio.py
    python ~/forge/forge_tokenmap.py
    python ~/forge/forgenet_correlation.py
    python ~/forge/forgenet_drift.py
    python ~/forge/forgenet_cluster.py
    bash ~/forge/voynich_f17r_sim/forge_heartbeat_notify.sh
    sleep 1800  # every 30 minutes
done
