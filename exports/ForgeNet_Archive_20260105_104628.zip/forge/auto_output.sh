#!/data/data/com.termux/files/usr/bin/bash
timestamp=$(date +%Y%m%d_%H%M%S)
logfile=~/forge/voynich_f17r_sim/output_$timestamp.txt
echo "🧠 Running command and saving to $logfile"
"$@" | tee "$logfile"
