#!/data/data/com.termux/files/usr/bin/bash
# === ForgeConfig Smart Console ===
FORGE_DIR=~/forge
WATCHDOG=$FORGE_DIR/forgenet_watchdog.sh
HEARTBEAT=$FORGE_DIR/voynich_f17r_sim/forge_heartbeat_notify.sh
DEST_DIR=~/storage/shared/Documents/ForgeNet
INTERVAL_DEFAULT=60

clear
echo "⚙️  ForgeConfig Smart Console"
echo "==============================="
echo "Detecting environment..."
echo

# Detect storage permission
if [ -d ~/storage/shared ]; then
  echo "✅ Storage access OK → ~/storage/shared"
else
  echo "⚠️  Storage not linked. Run: termux-setup-storage"
fi

# Detect watchdog state
if pgrep -f "forgenet_watchdog.sh" > /dev/null; then
  echo "🟢 Watchdog: ACTIVE"
else
  echo "🔴 Watchdog: INACTIVE"
fi

# Detect heartbeat
if [ -f "$HEARTBEAT" ]; then
  echo "💓 Heartbeat module found."
else
  echo "⚠️  Heartbeat missing or moved."
fi

echo
echo "=== Menu ==="
echo "1. Start Watchdog"
echo "2. Stop Watchdog"
echo "3. Change Watchdog interval"
echo "4. Set export destination (default: $DEST_DIR)"
echo "5. Test heartbeat notification"
echo "6. Run full Forge system check"
echo "7. Exit"
echo
read -p "Select an option [1-7]: " choice

case $choice in
  1)
    echo "▶ Starting Watchdog..."
    nohup bash "$WATCHDOG" >/dev/null 2>&1 &
    echo "✅ Watchdog started in background."
    ;;
  2)
    echo "⏹ Stopping Watchdog..."
    pkill -f forgenet_watchdog.sh && echo "✅ Watchdog stopped." || echo "No running Watchdog found."
    ;;
  3)
    read -p "Enter new interval (in seconds): " newint
    sed -i "s/INTERVAL=.*/INTERVAL=$newint/" "$WATCHDOG"
    echo "✅ Interval updated to $newint seconds."
    ;;
  4)
    read -p "Enter new destination path: " newdest
    sed -i "s|DEST_DIR=.*|DEST_DIR=$newdest|" "$WATCHDOG"
    echo "✅ Destination updated to $newdest"
    ;;
  5)
    echo "💓 Triggering heartbeat test..."
    bash "$HEARTBEAT"
    ;;
  6)
    echo "🔍 Running Forge system check..."
    echo "================================"
    echo
    ls -lh $FORGE_DIR | grep forgenet_
    echo
    echo "✅ Entropy logs:"
    ls -lh $FORGE_DIR/forgenet_logs | tail -n 5
    echo
    echo "✅ CSV/PNG outputs:"
    ls -lh $FORGE_DIR | grep -E 'csv|png'
    echo
    echo "System check complete."
    ;;
  7)
    echo "👋 Exiting ForgeConfig."
    ;;
  *)
    echo "❌ Invalid selection."
    ;;
esac
