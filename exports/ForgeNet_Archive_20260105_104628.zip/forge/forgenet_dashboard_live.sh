#!/data/data/com.termux/files/usr/bin/bash
INTERVAL=120  # refresh every 2 minutes
clear
echo "🧬 ForgeNet Live Dashboard (Ctrl+C to exit)"
echo "Refreshing every $INTERVAL seconds..."
echo "============================================================"
while true; do
    clear
    echo "🕒 $(date '+%Y-%m-%d %H:%M:%S') — ForgeNet Cognitive Pulse"
    echo "============================================================"
    bash ~/forge/forgenet_dashboard_cognitive.sh | grep -E "📊|🎨|🌊|🕒|🧩|✅|⚠️|🔴|🟡|🟢"
    echo "============================================================"
    echo "Next update in $INTERVAL seconds..."
    sleep $INTERVAL
done
