import time
from datetime import datetime
from sim_engine import analyze_text

LOGFILE = "entropy_trend.csv"

def log_entropy():
    ts = datetime.now().isoformat()
    # run the analysis and capture printed output
    from io import StringIO
    import sys
    buffer = StringIO()
    sys_stdout = sys.stdout
    sys.stdout = buffer
    analyze_text("f17r_eva.txt")
    sys.stdout = sys_stdout
    output = buffer.getvalue()

    # extract values
    h1 = None
    h2 = None
    for line in output.splitlines():
        if "Shannon entropy" in line:
            h1 = float(line.split(":")[1].split()[0])
        if "Bigram Conditional" in line:
            h2 = float(line.split(":")[1].split()[0])

    with open(LOGFILE, "a") as f:
        f.write(f"{ts},{h1},{h2}\n")
    print(f"[{ts}] h1={h1:.3f}, h2={h2:.3f} logged → {LOGFILE}")

if __name__ == "__main__":
    for i in range(10):
        log_entropy()
        time.sleep(1)
