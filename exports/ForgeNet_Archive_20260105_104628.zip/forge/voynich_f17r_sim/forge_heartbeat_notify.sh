#!/data/data/com.termux/files/usr/bin/bash
# === Smart Forge Heartbeat ===
LOG=~/forge/voynich_f17r_sim/entropy_autocycle.log
MSG="Forge cycle complete — entropy logged $(date '+%H:%M:%S')"

# Extract latest h1/h2 values if present
if [ -f "$LOG" ]; then
    ENTROPY_LINE=$(grep -E "h1=|Entropy" "$LOG" | tail -n 1)
    [ -n "$ENTROPY_LINE" ] && MSG="$MSG | $ENTROPY_LINE"
fi

# Feedback
termux-vibrate -d 300
termux-notification --title "Forge Heartbeat" --content "$MSG" --priority high
echo "$MSG" >> ~/forge/voynich_f17r_sim/heartbeat_log.txt

# Trigger ForgeNet snapshot
python ~/forge/forgenet_sync.py
