echo ">>> Updating ForgeFlow orchestrator for evolution integration..."
FLOW="$HOME/forge/forgeflow.sh"

if grep -q "forge_ai_sync.py" "$FLOW"; then
  awk '/forge_ai_sync.py/ {print; print "python ~/forge/voynich_f17r_sim/forge_evolve.py"; next}1' "$FLOW" > "$FLOW.tmp" && mv "$FLOW.tmp" "$FLOW"
  echo "✅  forge_evolve.py integrated after AI Sync."
else
  echo "⚠️  forge_ai_sync.py not found in forgeflow.sh — integration skipped."
fi
chmod +x "$FLOW"
echo "✅  ForgeFlow now includes autonomous evolution trigger."
echo ">>> All systems will now evolve after each adaptive cycle."
