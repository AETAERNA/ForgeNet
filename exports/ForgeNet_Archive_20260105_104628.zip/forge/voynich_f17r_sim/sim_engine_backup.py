import os, time, collections, math

def analyze_text(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read().lower()
    print(f"\nAnalyzing {file_path} — {len(text)} characters")
    freq = collections.Counter(ch for ch in text if ch.isalpha())
    total = sum(freq.values())
    entropy = -sum((c/total)*math.log2(c/total) for c in freq.values())
    print("\nTop letters:", freq.most_common(10))
    print(f"Shannon entropy: {entropy:.3f} bits/char")

    print("\nSimulating harmonic signature...")
    for i in range(5):
        print("🔄  wave cycle", i+1)
        time.sleep(0.3)
    print("✅  Simulation complete.")

if __name__ == "__main__":
    sample = "f17r_eva.txt"
    if not os.path.exists(sample):
        with open(sample, "w", encoding="utf-8") as f:
            f.write("qokedy qokedy qokedy qokedy qokedy ... example EVA text ...")
    analyze_text(sample)

# Add at top imports
from collections import Counter
import math

# In entropy calc section, after unigram h1
bigrams = Counter(zip(text, text[1:]))
h2 = 0
for (a, b), count in bigrams.items():
    p_bigram = count / (len(text) - 1)
    p_a = unigrams[a] / len(text)
    h2 -= p_bigram * math.log2(p_bigram / p_a if p_a > 0 else 1)
print(f"Bigram Conditional h2 Entropy: {h2:.3f} bits/char")

# CheDy boost tease (in evo/mutation section)
chedy_count = text.count('chedy')
if chedy_count > 70:
    print(f"CheDy conduit spike {chedy_count} >70 — boosting mutation x3 on chedy tables")
    # Add your mutation boost code here (e.g., evolve_tables(rate=3) on chedy tokens)

