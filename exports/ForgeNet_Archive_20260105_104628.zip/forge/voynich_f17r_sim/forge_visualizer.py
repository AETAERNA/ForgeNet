import csv, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

h1, h2, t = [], [], []
with open("entropy_trend.csv") as f:
    r = csv.reader(f)
    for row in r:
        t.append(row[0])
        h1.append(float(row[1]))
        h2.append(float(row[2]))

plt.plot(h1, label="Shannon h1")
plt.plot(h2, label="Conditional h2")
plt.title("Entropy Evolution")
plt.xlabel("Run #")
plt.ylabel("bits/char")
plt.legend()
plt.savefig("entropy_trend.png")
print("Saved → entropy_trend.png")
