from datetime import datetime

REPORT_PATH = "daily_heartbeat.txt"

def pulse(cycle_num, entropy, delta, spikes="none"):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{timestamp} | Cycle {cycle_num} | Entropy: {entropy:.3f} | Δ: {delta:.3f} | Spikes: {spikes}\n"
    with open(REPORT_PATH, "a") as f:
        f.write(line)
    print(line.strip())

if __name__ == "__main__":
    pulse(5, 3.355, 0.000)
