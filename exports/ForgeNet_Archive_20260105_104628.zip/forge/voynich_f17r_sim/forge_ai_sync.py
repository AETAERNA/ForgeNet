import csv, os
from datetime import datetime

def summarize_log(logfile="adaptive_log.csv"):
    if not os.path.exists(logfile):
        print("No adaptive log found.")
        return None
    with open(logfile, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        print("Log empty.")
        return None

    last = rows[-1]
    entropy = float(last["entropy"])
    length = last["length"]
    time = last["duration"]
    runs = len(rows)
    avg_entropy = sum(float(r["entropy"]) for r in rows) / runs
    trend = "🚀 exponential" if entropy > avg_entropy * 1.05 else "steady"
    summary = f"""
Forge Status Summary — {datetime.now().isoformat()}

Runs logged: {runs}
Last entropy: {entropy:.3f} bits/char
Average entropy: {avg_entropy:.3f}
Text length: {length}
Runtime: {time}s
Trend: {trend}

Path: ~/forge/voynich_f17r_sim/adaptive_log.csv
"""
    with open("forge_summary.txt", "w", encoding="utf-8") as f:
        f.write(summary)
    print(summary)

if __name__ == "__main__":
    summarize_log()
