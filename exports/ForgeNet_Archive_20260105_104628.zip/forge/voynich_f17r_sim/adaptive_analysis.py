import os, time, csv, math, collections
from datetime import datetime

LOGFILE = "adaptive_log.csv"

def analyze_text(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read().lower()
    freq = collections.Counter(ch for ch in text if ch.isalpha())
    total = sum(freq.values()) or 1
    entropy = -sum((c/total)*math.log2(c/total) for c in freq.values())
    return entropy, len(text)

def run_and_log(sample="f17r_eva.txt"):
    if not os.path.exists(sample):
        with open(sample,"w",encoding="utf-8") as f:
            f.write("qokedy qokedy qokedy ... example EVA text ...")
    start = time.time()
    entropy, length = analyze_text(sample)
    duration = time.time() - start

    row = [datetime.now().isoformat(), entropy, length, round(duration,3)]
    exists = os.path.exists(LOGFILE)
    with open(LOGFILE,"a",newline="",encoding="utf-8") as f:
        w = csv.writer(f)
        if not exists: w.writerow(["timestamp","entropy","length","duration"])
        w.writerow(row)

    print(f"Entropy={entropy:.3f} bits/char | Time={duration:.3f}s | Length={length}")
    if exists:
        with open(LOGFILE) as f: lines = list(csv.reader(f))[1:]
        if len(lines) > 1:
            prev = float(lines[-2][1])
            if entropy - prev > 0.1:
                print("🚀  Exponential improvement detected!")

if __name__ == "__main__":
    run_and_log()
