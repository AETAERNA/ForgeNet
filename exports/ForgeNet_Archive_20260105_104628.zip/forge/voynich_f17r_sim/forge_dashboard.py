import csv, os, statistics
from datetime import datetime

def sparkline(data, steps=10):
    if not data:
        return ""
    chars = "▁▂▃▄▅▆▇█"
    min_d, max_d = min(data), max(data)
    if min_d == max_d:
        return chars[0] * len(data)
    scaled = [(d - min_d) / (max_d - min_d) * (len(chars) - 1) for d in data]
    return "".join(chars[int(s)] for s in scaled)

def dashboard(logfile="adaptive_log.csv"):
    if not os.path.exists(logfile):
        print("No log found.")
        return
    with open(logfile, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        print("No runs recorded.")
        return

    entropies = [float(r["entropy"]) for r in rows]
    last = entropies[-1]
    avg = statistics.mean(entropies)
    trend = "🚀 exponential" if last > avg * 1.05 else "steady"
    print("==========================================")
    print("🧭  FORGE SYNC DASHBOARD")
    print("==========================================")
    print(f"Total runs: {len(rows)}")
    print(f"Last entropy: {last:.3f} bits/char")
    print(f"Average entropy: {avg:.3f}")
    print(f"Trend: {trend}")
    print(f"Sparkline: {sparkline(entropies)}")
    print(f"Last update: {datetime.now().isoformat()}")
    print("==========================================")

if __name__ == "__main__":
    dashboard()
