import os, time, collections, math
from collections import Counter

def analyze_text(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read().lower()

    print(f"\nAnalyzing {file_path} — {len(text)} characters")

    freq = collections.Counter(ch for ch in text if ch.isalpha())
    total = sum(freq.values())
    entropy = -sum((c / total) * math.log2(c / total) for c in freq.values())

    print("\nTop letters:", freq.most_common(10))
    print(f"Shannon entropy: {entropy:.3f} bits/char")

    # --- Bigram conditional entropy calculation ---
    bigrams = Counter(zip(text, text[1:]))
    h2 = 0.0
    for (a, b), count in bigrams.items():
        p_bigram = count / (len(text) - 1)
        p_a = freq[a] / total if a in freq else 0
        if p_a > 0:
            h2 -= p_bigram * math.log2(p_bigram / p_a)
    print(f"Bigram Conditional h2 Entropy: {h2:.3f} bits/char")

    # --- CheDy spike detection ---
    chedy_count = text.count('chedy')
    if chedy_count > 70:
        print(f"CheDy conduit spike {chedy_count} >70 — boosting resonance")

if __name__ == "__main__":
    analyze_text("f17r_eva.txt")
