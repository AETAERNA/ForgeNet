#!/data/data/com.termux/files/usr/bin/python
# === Forge Autocycle ===
import time, subprocess, datetime

LOG = "entropy_autocycle.log"

def log(msg):
    stamp = datetime.datetime.now().strftime("[%Y-%m-%d %H:%M:%S] ")
    with open(LOG, "a") as f:
        f.write(stamp + msg + "\n")
    print(stamp + msg)

def run_cycle():
    log("Running forge simulation cycle ...")
    try:
        out = subprocess.check_output(
            ["python", "sim_engine.py"], stderr=subprocess.STDOUT, text=True
        )
        log(out.strip())
    except subprocess.CalledProcessError as e:
        log("Error: " + e.output)

# --- main loop ---
while True:
    run_cycle()
    log("Cycle complete. Sleeping 1 hour.")
    time.sleep(3600)
