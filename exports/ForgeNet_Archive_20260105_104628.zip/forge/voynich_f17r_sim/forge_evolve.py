import os, re, csv, math, time, collections
from datetime import datetime

LOG = "adaptive_log.csv"
EVOLVE_LOG = "forge_evolve_log.txt"

def read_entropy_trend():
    if not os.path.exists(LOG):
        return []
    with open(LOG, newline="", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    return [float(r[1]) for r in rows[1:] if len(r) > 1 and r[1].replace('.','',1).isdigit()]

def evolve_tables(force=False):
    """Placeholder for adaptive parameter tuning."""
    with open(EVOLVE_LOG, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now().isoformat()} :: evolve_tables triggered (force={force})\n")
    print("⚙️  Adaptive tables evolved.")

def detect_resonance_spikes(sample="f17r_eva.txt"):
    """Scan EVA text for token clusters that resemble resonant elements."""
    if not os.path.exists(sample):
        print("No sample found; skipping resonance scan.")
        return []
    with open(sample, "r", encoding="utf-8") as f:
        text = f.read().lower()
    tokens = re.findall(r"[a-z]+", text)
    counts = collections.Counter(tokens)
    total = sum(counts.values()) or 1
    avg = sum(counts.values()) / len(counts)
    spikes = [t for t, c in counts.items() if c > 2 * avg and any(x in t for x in ["res","tub","sol"])]
    if spikes:
        print("🔮 Resonance spikes detected:", ", ".join(spikes))
    else:
        print("No resonance spikes found.")
    return spikes

def forge_cycle():
    trend = read_entropy_trend()
    if len(trend) < 2:
        print("Not enough runs for trend analysis.")
        return
    delta = abs(trend[-1] - trend[-2])
    print(f"ΔEntropy={delta:.3f}")
    if delta < 0.05:
        print("⚠️  Entropy stable → triggering accelerated evolution.")
        evolve_tables(force=True)
    spikes = detect_resonance_spikes()
    if spikes:
        with open(EVOLVE_LOG, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now().isoformat()} :: spikes={','.join(spikes)}\n")

if __name__ == "__main__":
    print("=== Forge Evolution Cycle Initiated ===")
    forge_cycle()
    print("=== Evolution Cycle Complete ===")
