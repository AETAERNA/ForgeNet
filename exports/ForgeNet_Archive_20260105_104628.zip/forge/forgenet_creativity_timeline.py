#!/data/data/com.termux/files/usr/bin/python
import os, csv, datetime, json

LOG_PATH = os.path.expanduser("~/forge/forgenet_creativity_log.txt")
OUT_PATH = os.path.expanduser("~/forge/forgenet_creativity_timeline.json")

# Fallback seeding if log missing or empty
if not os.path.exists(LOG_PATH) or os.path.getsize(LOG_PATH) < 10:
    print("⚠️  No creativity log yet — generating starter timeline.")
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "w") as f:
        f.write("timestamp,creative_index,variance,note\n")
        f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S},0.40,0.05,auto_seed\n")

# Parse entries
entries = []
with open(LOG_PATH, "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        try:
            ts = row.get("timestamp")
            ci = float(row.get("creative_index", 0))
            var = float(row.get("variance", 0))
            note = row.get("note", "")
            entries.append({
                "timestamp": ts,
                "creative_index": ci,
                "variance": var,
                "note": note
            })
        except Exception:
            continue

if not entries:
    print("⚠️  Still no valid entries — check log format.")
    exit(0)

# Sort and export timeline JSON
entries.sort(key=lambda x: x["timestamp"])
with open(OUT_PATH, "w") as out:
    json.dump(entries, out, indent=2)

print(f"✅ Creativity timeline written → {OUT_PATH}")
print(f"🧠 {len(entries)} entries processed.")
