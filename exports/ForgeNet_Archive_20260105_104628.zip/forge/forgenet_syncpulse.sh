#!/data/data/com.termux/files/usr/bin/bash
echo "=== Forge Synchrony Pulse ==="
FILES=(
  "~/forge/forgenet_master.csv"
  "~/forge/forgenet_montecarlo.json"
  "~/forge/forgenet_creativity_map.txt"
  "~/forge/forgenet_research_log.txt"
)
for f in "${FILES[@]}"; do
  path=$(eval echo $f)
  if [ -f "$path" ]; then
    age=$(( ($(date +%s) - $(stat -c %Y "$path")) / 60 ))
    if [ $age -lt 120 ]; then
      echo "✅ Alive ($age min) — $path"
    else
      echo "⚠️ Stale ($age min) — $path"
    fi
  else
    echo "❌ Missing — $path"
  fi
done
echo "=== Pulse Complete ==="
