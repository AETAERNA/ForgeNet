#!/data/data/com.termux/files/usr/bin/python
import os, re, collections

data_dir = os.path.expanduser("~/forge/voynich_f17r_sim")
files = [f for f in os.listdir(data_dir) if f.endswith("_eva.txt")]

# top 10 repeating words overall
word_counts = collections.Counter()
for f in files:
    with open(os.path.join(data_dir, f), "r", encoding="utf-8", errors="ignore") as fh:
        for w in re.findall(r"[a-z]+", fh.read().lower()):
            word_counts[w] += 1

top_words = [w for w, _ in word_counts.most_common(10)]
matrix = []

for f in sorted(files):
    row = [f]
    text = open(os.path.join(data_dir, f), "r", encoding="utf-8", errors="ignore").read().lower()
    for w in top_words:
        row.append(text.count(w))
    matrix.append(row)

# print header + matrix
header = ["folio"] + top_words
print("\t".join(header))
for r in matrix:
    print("\t".join(str(x) for x in r))
